<?php
include("../connection.php");
 if(isset($_POST['submit']))
 {

//$name =$_FILES['file']['name'];
//echo $name;
//$temp_name =$_FILES['file']['tmp_name'];
//move_uploaded_file($temp_name,'upload/'.$name);
 
$name=$_POST['Name'];
//echo $name;
$phone=$_POST['Phone'];
//echo $phone;
$email=$_POST['Email'];
//echo $email;

$pass=$_POST['CreatePassword'];
//echo $pass;



$sql="Insert into login(email,password,status,role,logstatus) values('$email','$pass',0,'user',1)";
$obj=new db();
$obj->execute($sql);
$sel="select login_id from login where email='$email' and password='$pass'";
$login=$obj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";
$lo=$strr[0];

//echo $str['login_id']; or option of above
$sqlll="Insert into register(name,email,phone,login_id) values('$name','$email',$phone,$lo)";
$objj=new db();
$objj->execute($sqlll);
}
// }
 header("location:../login/login.php");
?>