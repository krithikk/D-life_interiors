<!DOCTYPE html>
<html lang="en">
<head>
<script src="js/validate.js">
</script>
<script>
function pwdChek() 
		{														
			if(document.getElementById("password").value == document.getElementById("cnpwd").value)
			{	
				return true;										
			}
			else
			{
				alert("***Password Mismatch***");
                                cnpwd.value="";
                                cnpwd.focus();
			  
					return false;
			}
		}
		
    </script>

		<meta charset="utf-8">
		<title>Registration user</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
   <body>
    <div class="wrapper">
    <div class="image-holder">
			<a href="../index.php" > HOME </a>
				<img src="images/new3.jpg" alt="">
			</div>
			<div class="form-inner">
			<form action="regaction.php" method="post">
					<div class="form-header">
						<h3>Sign up</h3>
						</div>
					<div class="form-group">
						<label for="">Your name here:</label>
						<input type="text" autocomplete="off" name="Name" id="Name" placeholder="your name"  
						class="form-control" pattern="[a-zA-Z ]{5,}" required=""  >
					</div>
					<div class="form-group">
						<label for=""> Your E-mail here:</label>
						<input type="email" autocomplete="off" name="Email" id="Email" placeholder="your Email Address" oninput="this.reportValidity()" onchange="em()" class="form-control" data-validation="email">
					</div>
					<div class="form-group">
						<label for="">Your Contact no here:</label>
						<input type="text" autocomplete="off" name="Phone" id="Phone" placeholder="your contact no" oninput="this.reportValidity()" onchange="p()" pattern="[7-9][0-9]{9}" title="phone number with 7-9 and remaining 9 digit with 0-9"class="form-control" >
					</div>
					<!--//<div class="form-group">
						<label for="">Your Aadhar no here:</label>
						<input type="text" autocomplete="off" name="aadharno" id="txtAadhar"  onblur="AadharValidate();" placeholder="your aadhar no" class="form-control" >
					</div>-->
					
					
					<div class="form-group" >
						<label for=""> Your Password here:</label>
						<input type="Password"  autocomplete="off" name="Password" id="password" placeholder="Your Password here"  pattern=".{4,}" title="four or more characters" class="form-control" >
					</div>
					<div class="form-group" >
						<label for=""> Confirm Your Password here:</label>
						<input type="Password" class="form-control"  name="cpassword" id="cnpwd" onchange="pwdChek();" placeholder=" confirm Your  Password here"   >
					</div>
					<!--<div class="form-group">
                            <input type="password" class="form-input" name="cpassword" id="cnpwd" onchange="pwdChek();"   placeholder=" Confirm Your Password"/>
                          </div>-->
					<div class="bottom">
					<button type="submit" name="submit" class="btn" >Register</button>
					</div>
				
				</form>
			</div>
			
		</div>
		
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/jquery.form-validator.min.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>