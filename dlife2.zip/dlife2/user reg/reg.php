<!DOCTYPE html>
<html>
	<head>
	<script src="js/validate.js"> </script>
	
	<script type="text/javascript" language="javascript" src="javascripts/jquery.js"> </script>
	<script type="text/javascript" language="javascript" src="javascripts/script.js"> </script>
	

     
		<meta charset="utf-8">
		<title>Registration user</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
   <body>
    <div class="wrapper">
    <div class="image-holder">
		<a href="../index.php" > HOME </a>	
				<img src="images/a1.jpg" alt="">
			</div>
			<div class="form-inner">
			<form method="post" action="regaction.php" name="create_customer" id="create_customer" >
					<div class="form-header">
						<h3>Sign up</h3>
						</div>
					<div class="form-group">
						<label for="">Your name here:</label>
						<input type="text" name="Name" id="Name" placeholder="your name" autocomplete="off" class="form-control"  >
						<span id="name_error_message" style="color:red"></span>
					</div>
					<div class="form-group">
						<label for="">Your Contact no here:</label>
						<input type="text" name="Phone" id="Phone" placeholder="your contact no" autocomplete="off"  class="form-control"  >
						<span id="phone_error_message" style="color:red"></span>
					</div>
					<div class="form-group">
						<label for=""> Your E-mail here:</label>
						<input type="email" name="Email" id="Email" placeholder="your Email Address" autocomplete="off" class="form-control" >
						<span id="email_error_message" style="color:red"></span>
					</div>
					
					<div class="form-group" >
						<label for=""> Your Password here:</label>
						<input type="Password" name="CreatePassword" id="CreatePassword" autocomplete="off"  placeholder="Your Password here"   class="form-control"  >
						<span id="password_error_message" style="color:red"></span> 
					</div>
					<div class="form-group" >
						<label for=""> Confirm Your Password here:</label>
						<input type="Password" name="CPassword" id="CPassword" autocomplete="off"  placeholder="Enter a confirm  Password.."  class="form-control"  >
						<span id="cpassword_error_message" style="color:red"></span>
					</div>
					<div class="bottom">
						<button type="submit" id="submit" name="submit" class="btn">Register</button>
						
					</div>
				</form>
			</div>
		</div>
		
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/jquery.form-validator.min.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>