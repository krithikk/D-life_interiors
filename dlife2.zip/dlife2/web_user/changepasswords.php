   <!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
  include("../connection.php");
  include("check_session.php");

?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>User Home</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="Promote Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <!-- //Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	  <link rel="stylesheet" href="css/slider.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <!-- font-awesome-icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
   <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!-- //Fonts -->
</head>
<body>
   <!-- header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-rocket"></span> D'LIFE </a></h1>
			</div>

			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
				<li class="active"><a href="userhome.php">Home</a></li>
				
				<li><a class="drop" href="t.php">Products Categories</a>
				
            <li><a class="drop" href="#">Profile</a>
            <ul>
			        <li class=""><a href="profile.php"> View Profile</a></li>
					<li><a class="" href="editprofile1.php">Edit Profile</a>
					
					</ul>
				<li><a class="drop" href="#">Account</a>
            <ul>
              
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>
				
              <!--<li><a href="pages/sidebar-right.html">Sidebar Right</a></li>
              <li><a href="pages/basic-grid.html">Basic Grid</a></li>-->
            </ul>
          </li>
				
				<!--<li><a class="drop" href="#">Account</a>
            <ul>
              <li class=""><a href="profile.php">My Profile</a></li>
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>-->
				
				
				<li class="last-grid"><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
		<!-- //nav -->
	</div>
</header>
<!-- //header -->


<!-- banner -->
<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="banner-text-w3pvt">
				<!-- banner slider-->
				<div class="csslider infinity" id="slider1">
					<input type="radio" name="slides" checked="checked" id="slides_1" />
					<input type="radio" name="slides" id="slides_2" />
					<input type="radio" name="slides" id="slides_3" />
					<ul class="banner_slide_bg">
						<li>
							<center><center>
<div align="center">
<div class="container">

 <form name="myForm"  method="post"  autocomplete="off"

 
   onsubmit="return validateForm()" method="post">
   
   
  
  <br> 
	
	<div class="row">
      <div class="col-25">
        <label for="entername">CURRENT EMAIL:</label>
      </div>
      <div class="col-75">
       <input type="email"  name="email1" id="email1" placeholder="Email id.." required>
        
      </div>
    </div>
<br>    

<div class="row">
      <div class="col-25">
        <label for="dob"> NEW PASSWORD:</label>
      </div>
	  <div class="col-75">
 <input type="password" id="password" name="newpassword"  id="newpassword"  placeholder="New password..." pattern="{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        
	   </div>
      </div>
	 
    <br>
	
<div class="row">
      <div class="col-25">
        <label for="dob"> CONFIRM 
		 PASSWORD:</label>
      </div>
	  
      <div class="col-75">
 <input type="password" id="password" name="confirmnewpassword" id="confirmnewpassword"  placeholder="Confirm Password.." pattern="{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
      
	   </div>
      </div>
	
<center>	
 <div class="row" align="center">
 
     <div class="col-25">
  <center><center><input type="submit" name="submit"  value="UPDATE"></center> </center><br>
</center>
 </div>
 </div>
 </div>
 </div>
  </center>
   </center>
						</li>
						
					</ul>
					
				</div>
				<!-- //banner slider-->
			</div>
		</div>
	</div>
</div>


<head>
<style>


input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

body {
  margin: 0;
  padding: 0;
  background:violet;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}

.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit] {
    
    background-color: pink;
	width: 100%;
    padding: 20px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}


.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}
a{
	color: white;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
 </style>
</head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>



 <!--
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>Password Change</title>
     </head>
    <body>
    <h1>Change Password</h1>
   <form method="POST" action="changepasswords.php">
    <table>
    <tr>
   <td>Enter your Email</td>
    <td><input type="email" size="10" id="email1" name="email1"></td>
    </tr>
    
  <tr>
    <td>Enter your new password:</td>
    <td><input type="password" size="10" name="newpassword" id="newpassword"></td>
    </tr>
    <tr>
   <td>Re-enter your new password:</td>
   <td><input type="password" size="10" name="confirmnewpassword" id="confirmnewpassword"></td>
    </tr>
    </table>
    <p><input type="submit"  name="submit" value="Update Password">
    </form>
   <p><a href="HOME1.php">Home</a>
   <p><a href="logout.php">Logout</a>
   </body>
    </html> -->




   
     
	
	</form>  
	
   
<?php
include "conn.php";
//session_start();
/*include "connection.php";
if(isset($_POST['submit']))
 {
        $email = $_POST['email'];
	
        
        $newpassword =$_POST['newpassword'];
	
        $confirmnewpassword = $_POST['confirmnewpassword'
        $result = mysql_query (con,"SELECT password FROM org1 WHERE  email='$email'");
		  
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($password!= mysql_result($result, 0))
        {
        echo "You entered an incorrect password";
        }
        if($newpassword=$confirmnewpassword)
        $sql=mysql_query(" UPDATE org1 SET password='$newpassword' where email='$email'");
        if($sql)
        {
        echo "Congratulations You have successfully changed your password";
        }
       else
        {
       echo "Passwords do not match";
	  
       }
 }
      ?>*/
	  
	 
if(isset($_POST['submit']))
{
$uname=	$_POST["email1"];
$new=$_POST["newpassword"];
$conf=$_POST["confirmnewpassword"];
$re= mysqli_query($con,"select * from login where email='$uname'");


if(mysqli_num_rows($re)>0)
{
	
	if ($new==$conf)
	{ 
	mysqli_query($con,"update login set password='$new' where email='$uname'");
	?>
		<script>
		alert("successfully updated")
		</script>
		<?php
	}
	else
	{
		?>
		<script>
		alert("Password MisMatch")
		</script>
	
<?php
	}
}
else
{
	
	?>
    
    <script>
	alert("Password Does not exists")
	</script>    
    <?php }
}?>

 
	  
	  
	  
	  
	  
	 
</body>
    </html>  