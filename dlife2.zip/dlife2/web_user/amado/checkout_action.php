<?php
include("../../connection.php");
 if(isset($_POST['submit']))
 {

//$name =$_FILES['file']['name'];
//echo $name;
//$temp_name =$_FILES['file']['tmp_name'];
//move_uploaded_file($temp_name,'upload/'.$name);
 
$name=$_POST['Name'];
//echo $name;
$phone=$_POST['Phone'];
//echo $phone;
$email=$_POST['Email'];
//echo $email;
$cname=$_POST['Cname'];
//echo $cname;
$product=$_POST['Product'];
//echo $product;
$city=$_POST['City'];
//echo $city;
$country=$_POST['Country'];
//echo $country;
$address=$_POST['Address'];
//echo $address;
$zipcode=$_POST['Zipcode'];
//echo $zipcode;
$nme =$_FILES['picture']['name'];
////echo $nme;
$temp_name =$_FILES['picture']['tmp_name'];
move_uploaded_file($temp_name,'upload/'.$nme);
//$pass=$_POST['CreatePassword'];
//echo $pass;



/*$sql="Insert into login(email,password,status,role,logstatus) values('$email','$pass',0,'user',1)";
$obj=new db();
$obj->execute($sql);

//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";*/
$objj=new db();
/*
$sel="select category_id from category where categoryname=$cname";
$login=$objj->execute($sel);
$strr=mysqli_fetch_array($login);
$co=$strr[0];
echo $co;
$sell="select product_id from product where product=$product";
$loginn=$objj->execute($sell);
$strrr=mysqli_fetch_array($loginn);
$po=$strrr[0];
echo $po;*/
//echo $str['login_id']; or option of above
$sqlll="Insert into book(name,email,address,city,zipcode,phone,country,picture,category_id,product_id) values('$name','$email','$address','$city','$zipcode','$phone','$country','$nme',$cname,$product)";
//$objj=new db();
$objj->execute($sqlll);
}
// }
header("location:../amado/checkout.php");
?>