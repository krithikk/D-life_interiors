<?php
//session_start();
$con=mysqli_connect("localhost","root","","dlife_inter");
if(!$con)
//{
	//echo "database is  not connected";
//}
//else
//{
	//echo"database is connected";
//}
?>