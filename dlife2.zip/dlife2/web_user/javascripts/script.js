$(function() {

	//$("#name_error_message").hide();
	//$("#lname_error_message").hide();
	//$("#password_error_message").hide();
	//$("#cpassword_error_message").hide();
	//$("#email_error_message").hide();
	$("#phone_error_message").hide();
	$("#address_error_message").hide();
	$("#cname_error_message").hide();
	$("#product_error_message").hide();
	//$("#zipcode_error_message").hide();
	//$("#comment_error_message").hide();
	$("#city_error_message").hide();
	$("#country_error_message").hide();
	//$("#quali_error_message").hide();
	//$("#picture_error_message").hide();
	//$("#picture2_error_message").hide();

	//var error_name = false;
	//var error_lname = false;
	//var error_password = false;
	//var error_retype_password = false;
	//var error_email = false;
	var error_phone = false;
	var error_cname = false;
	var error_product = false;
	//var error_zipcode = false;
	//var error_comment = false;
	var error_city = false;
	var error_country = false;
	//var error_quali = false;
	//var error_picture = false;
	//var error_picture2 = false;
	var error_address = false;
	var pattern = /^[a-zA-Z]*$/;
		
//first name
	/*$("#Name").focusout(function() {

		check_username();
		//alert("error");
		
	});
	
//last name
	$("#Lastname").focusout(function() {

		check_lname();
		//alert("error");
		
	});*/
	//phone
	$("#Phone").focusout(function() {

		check_phone();
		//alert("err");
		
	});
	
	
	//email
	/*$("#Email").focusout(function() {

		check_email();
		
	});*/
	//address
	$("#Address").focusout(function() {

		check_address();
		
	});
	//city
	$("#City").focusout(function() {

		check_city();
		
	});
	//country
	$("#Country").focusout(function() {

		check_country();
		
	});
	//zipcode
	/*$("#Zipcode").focusout(function() {

		check_zipcode();
		
	});*/
	//Category name
	$("#Cname").focusout(function() {

		check_cname();
		
	});
	//product name 
	$("#Product").focusout(function() {

		check_product();
		
	});
	//comment
	/*$("#Comment").focusout(function() {

		check_comment();
		
	});
	//qualification
	/*$("#Qualification").focusout(function() {

		check_quali();
		//alert("error");
	});*/
	//picture
	/*$("#File1").focusout(function() {

		check_picture();
		//alert("err");
		
	});
	
	//picture2
	$("#picture2").focusout(function() {

		check_picture2();
		//alert("error");
	});
	//pass
	$("#CreatePassword").focusout(function() {

		check_password();
		//alert("err");
	});
	//conf pass

	$("#CPassword").focusout(function() {

		check_retype_password();
		
	});*/
	
	//firstname
	/*function check_username() {
		var name = $("#Name").val();
		if(pattern.test(name) && name != '')
		{
			
			$("#name_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#name_error_message").html("Enter valid name");
			$("#name_error_message").show();
			error_name = true;
			//$( "#FirstName" ).focus();
		}
      }
	
		*/
	
	//phone
	
	function check_phone() {
		//var pattern = /([0-9]{10})|(\([0-9]{3}\)\s+[0-9]{3}\-[0-9]{4})/;
		//var patter = /^\(?(\d{3})\)?[-\. ]?(\d{3})[-\. ]?(\d{4})$/;
		var patter =/^(?!(\d)\1{9})(?!0123456789|1234567890|9000000000|800000000|700000000|600000000|500000000)\d{10}$/ ;
		var phone = $("#Phone").val();
		if(patter.test(phone) && phone != '')
		{
			
			$("#phone_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#phone_error_message").html("Enter valid phone number");
			$("#phone_error_message").show();
			error_phone = true;
			//$( "#Phone" ).focus();
		}
	}
	//zipcode
	/*function check_zipcode() {
		//var pattern = /([0-9]{10})|(\([0-9]{3}\)\s+[0-9]{3}\-[0-9]{4})/;
		//var patter = /^\(?(\d{3})\)?[-\. ]?(\d{3})[-\. ]?(\d{4})$/;
		var patter =/^(?!(\d)\1{9})(?!0123456|123456|900000|800000|700000|600000|500000)\d{6}$/ ;
		var zipcode = $("#Zipcode").val();
		if(patter.test(zipcode) && zipcode != '')
		{
			
			$("#zipcode_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#zipcode_error_message").html("Enter valid zipcode");
			$("#zipcode_error_message").show();
			error_zipcode = true;
			//$( "#zipcode" ).focus();
		}
	}
	//comment
	function check_comment() {
		var name = $("#Comment").val();
		if(pattern.test(name) && name != '')
		{
			
			$("#comment_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#comment_error_message").html("Enter comments");
			$("#comment_error_message").show();
			error_comment = true;
			//$( "#FirstName" ).focus();
		}
}*/
//address
function check_address() {
		var name = $("#Address").val();
		if(pattern.test(name) && name != '')
		{
			
			$("#address_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#address_error_message").html("Enter valid address");
			$("#address_error_message").show();
			error_address = true;
			//$( "#FirstName" ).focus();
		}
}
//category name
function check_cname() {
		var name = $("#Cname").val();
		if(name != 'cname')
		{
			
			$("#cname_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#cname_error_message").html("Enter valid category");
			$("#cname_error_message").show();
			error_cname = true;
			//$( "#FirstName" ).focus();
		}
}

//product name
function check_product() {
		var name = $("#Product").val();
		if(pattern.test(name) && name != '')
		{
			
			$("#product_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#product_error_message").html("Enter valid product");
			$("#product_error_message").show();
			error_product = true;
			//$( "#FirstName" ).focus();
		}
}
	//last name
	/*function check_lname() {
		var LastName = $("#Lastname").val();
		if(pattern.test(LastName) && LastName != '')
		{
			
			$("#lname_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#lname_error_message").html("Enter valid name");
			$("#lname_error_message").show();
			error_lname = true;
			//$( "#LastName" ).focus();
		}
	}
	//email
	
	function check_email() {

		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
	
		if(pattern.test($("#Email").val())) 
		{
			//$("#email_error_message").hide();
		
		 $('#Email').on('blur', function(){
 	var email = $('#Email').val();
 	if (email == '') {
 		error_email = true;
 		return;
 	}
 	$.ajax({
      url: 'checkemail.php',
      type: 'post',
      data: {
      	'email_check' : 1,
      	'Email' : email,
      },
      success: function(response){
      	if (response == 'taken' ) {
          error_email = true;
          $("#email_error_message").html("Email already exists");
			$("#email_error_message").show();
          //$('#Email').parent().removeClass();
          //$('#Email').parent().addClass("form_error");
          //$('#Email').siblings("span").text('Sorry... Email already taken');
      	}
      	else if (response == 'not_taken') {
      	  error_email = false;
      	  $("#email_error_message").hide();
      	}
      }
 	});
 });
	} else {
			$("#email_error_message").html("Enter valid email ");
			$("#email_error_message").show();
			error_email = true;
			//$( "#Email" ).focus();
		}
	}*/
	//country
	function check_country() {
		var name = $("#Country").val();
		if(name != 'country')
		{
			
			$("#country_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#country_error_message").html("Enter valid city");
			$("#country_error_message").show();
			error_quali = true;
			//$( "#FirstName" ).focus();
		}
}
//city
function check_city() {
		var City = $("#City").val();
		if(pattern.test(City) && City != '')
		{
			
			$("#city_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#city_error_message").html("Enter valid city");
			$("#city_error_message").show();
			error_lname = true;
			//$( "#LastName" ).focus();
		}
	}
/*
function check_picture() {
		

(function($) {
$.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    $('#File1').checkFileType({
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
        success: function() {
            //alert('Success');
            $("#picture_error_message").hide();
        },
        error: function() {
            //alert('Error');
            $("#picture_error_message").html("Enter picture with .jpg .jpeg .png .pdf format ");
			$("#picture_error_message").show();
			error_picture = true;
        }
    });
		
	});
}*/
	//last name
	
/*function check_picture2() {
		(function($) {
$.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    $('#picture2').checkFileType({
        allowedExtensions: ['jpg', 'jpeg', 'png'],
        success: function() {
            //alert('Success');
            $("#picture2_error_message").hide();
        },
        error: function() {
            //alert('Error');
            $("#picture2_error_message").html("Enter picture with .jpg .jpeg .png format");
			$("#picture2_error_message").show();
			error_picture2 = true;
        }
    });
		
	});
	}
		function check_password() {
	
		var password_length = $("#CreatePassword").val().length;
		
		if(password_length < 6) {
			$("#password_error_message").html("At least 6 characters");
			$("#password_error_message").show();
			error_password = true;
			//$( "#CreatePassword" ).focus();
		} else {
			$("#password_error_message").hide();
		}
	
	}

	function check_retype_password() {
	
		var password = $("#CreatePassword").val();
		var cpassword = $("#CPassword").val();
		
		if(password !=  cpassword) {
			$("#cpassword_error_message").html("Password don't match the above");
			$("#cpassword_error_message").show();
			error_retype_password = true;
			//$( "#CPassword" ).focus();
		} else {
			$("#cpassword_error_message").hide();
		}
	
	}
	*/
	$("#create_customer").submit(function() {
		//error_name = false;
		//error_lname = false;
		//error_email = false;
		//error_comment = false;
		error_city = false;
		error_address = false;
		error_country = false;
		//error_zipcode = false;
		error_cname = false;
		error_product = false;
		//error_password =  false;
		//error_retype_password = false;
		error_phone = false;
		//error_picture = false;
		//error_picture2 = false;
		
		
		//check_username();
		//check_lname();
		//check_email();
		//check_password();
		//check_retype_password();
		check_phone();
		check_cname();
		check_product();
		check_city();
		check_country();
		check_address();
		//check_zipcode();
		//check_picture();
		//check_picture2();
		check_comment();
		if (error_cname === false && error_address === false && error_phone === false&& error_city === false  && error_product === false && error_city === false && error_country === false) {
			alert("Registration successful");
			return true;

		}
		else
		{
			alert("Please fill the form correctly");
			return false;
		}	
	});
});