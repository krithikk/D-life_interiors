<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
  include("../connection.php");
  include("check_session.php");

?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Products View</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="Promote Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <!-- //Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	  <link rel="stylesheet" href="css/slider.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <!-- font-awesome-icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
   <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!-- //Fonts -->
	
	<style>
.buttons {
  background-color: pink; /* Green */
  border: none;
  color: black;
  padding: 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button3 {border-radius: 8px;}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: blue;
  padding: 1px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
<body>
   <!-- header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="userhome.php"><span class="fa fa-rocket"></span> D'LIFE </a></h1>
			</div>

			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
				<li class="active"><a href="userhome.php">Home</a></li>
				<li class=""><a href="#about">About Us</a></li>
			
				<li><a class="" href="t.php">Products Categories</a>
				
            
			
 
 
   
   <!--<ul>
   <?php

 
$obj=new db();
$select="select * from category";
$data=$obj->execute($select);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	
$categoryname=$row['categoryname'];

echo '<li>';
echo $categoryname;
echo '</li>';
}
}
?>
  

 
              
            </ul>
          </li>-->
		  <li><a class="drop" href="#">Profile</a>
            <ul>
			        <li class=""><a href="profile.php"> View Profile</a></li>
					<li><a class="" href="editprofile1.php">Edit Profile</a>
					
					</ul>
				<li><a class="drop" href="#">Account</a>
            <ul>
              
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>
				
				
				<li class="last-grid"><a href="logout.php">Logout</a></li>
				</ul>
			</ul>
		</nav>
		<!-- //nav -->
	</div>
	<style>
.tkvsoft ul {
	position: absolute;
	
	z-index:9;

	opacity: 0;
	
	background: #fff;

	-webkit-border-radius: 0 0 5px 5px;
	-moz-border-radius: 0 0 5px 5px;
	border-radius: 0 0 5px 5px;

	-webkit-transition: opacity .25s ease .1s;
	-moz-transition: opacity .25s ease .1s;
	-o-transition: opacity .25s ease .1s;
	-ms-transition: opacity .25s ease .1s;
	transition: opacity .25s ease .1s;
}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;

	-webkit-transition: height .25s ease .1s;
	-moz-transition: height .25s ease .1s;
	-o-transition: height .25s ease .1s;
	-ms-transition: height .25s ease .1s;
	transition: height .25s ease .1s;
}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
}

.tkvsoft ul li a {
	width: 200px;
	padding:40px;
	margin: 0;

	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }
</style>

</header>
<!-- //header -->


<!-- banner -->
<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="banner-text-w3pvt">
				<!-- banner slider-->
				<div class="csslider infinity" id="slider1">
					<input type="radio" name="slides" checked="checked" id="slides_1" />
					<input type="radio" name="slides" id="slides_2" />
					<input type="radio" name="slides" id="slides_3" />
					<h1 class="b-w3ltxt" style="color:white">Search by categories and view products</h1>
					<button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
<div width="100%" height="100%";>
				<br><center><center><form method="get">
		     <select id="cat" name="cat" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;color: black;display: block;width:20%;"  required="" onchange="return dist()" required>
                    <option>--search by category--</option>
                    <?php
					include("dbconnect.php");
                    $con=mysqli_connect("localhost","root","","dlife_inter");
					$_session["unm"]=$username;
					$sql="SELECT * FROM category";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['category_id'];
                        $name=$row['categoryname'];
                        ?>
                        
                        <option value='<?php echo $id ?>'><?php echo $name ?></option>;
                        <?php
                    }
                    ?>
                    </select>
		
		<button class="buttons button3">Search here...</button>
		</div>
		</form></center>
		</center>
		
					
					 <?php
		if(isset($_GET['cat']))
		{
				$sql="SELECT * FROM `product` where category_id='".$_GET['cat']."'		";	
		}
		else
		{
		$sql="SELECT PR.*,L.* FROM product PR,login L where L.login_id=PR.login_id and L.status='1'";

		}
		
		$res=mysqli_query($con,$sql);
		$rowcount=mysqli_num_rows($res);
		if(!$rowcount)
		{
			echo 'No Result Found';
		}
		else{
		while($row=mysqli_fetch_array($res))
		{
		$pimage=$row['picture'];
		$pname=$row['product'];
		$price=$row['price'];
		
		?>
		
		
		<div style="display:inline-block;background:black;">
		
		
		
					<div class="card">
                    <img src="../Admin/upload/<?php echo $pimage ?>" width="75" height="150" style="width:75%">
					</div>
					<ul >
						    <li>Name:<?php echo $pname ?></li>
						    <li>Price:<?php echo $price ?></li>
						
						</ul>
                  <!-- <h1>Tailored Jeans</h1>
                   <p class="price">$19.99</p>-->
				   
                   <p><a href="amado/product-details.php?id=<?php echo $row['product_id'];?>"><center><button class="button">View more..</button></center></a></p>-->
				  <!-- <form action="amado/product-details.php" method="POST">
				   <input type ="hidden" name="id" value="<?php echo $row['product_id']; ?>" />
				   <input type="submit" value="View more" class="button">-->
                   </div>
				   <?php
							}
							}
							?>
					
				</div>
				<!-- //banner slider-->
			</div>
		</div>
	</div>
</div>
<!--<style>
body {
	background-image: url("images/table.jpg");
	height:1000px;
	
}
</style>-->

<!-- //banner -->
<!-- about -->

<!-- //Projects -->
<!-- /plans -->
   <!-- <section class="plans-sec py-5" id="plans">
        <div class="container py-md-5 py-3">
		<h5 class="heading mb-2"> Exclusive prices</h5>
		<h3 class="heading mb-sm-5 mb-3">We Provide Best price</h3>
                    <div class="row pricing-plans">
                        <div class="col-md-4 price-main text-center mb-4">
                            <div class="pricing-grid card">
                                <div class="card-body">
                                    <span class="fa fa-user-o" aria-hidden="true"></span>
                                    <h4 class="text-uppercase">Basic</h4>
                                    <h5 class="card-title pricing-card-title">
                                        <span class="align-top">$</span>199

                                    </h5>
                                   <p>We help you to grow up your business and solution for your impressive projects.</p>
                                    <div class="price-button mt-md-3 mt-2">
                                        <a class="btn text-uppercase" href="#contact">
                                            Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 price-main price-main1  text-center mb-4">
                            <div class="pricing-grid card">
                                <div class="card-body">
                                    <span class="fa fa-female" aria-hidden="true"></span>
                                    <h4 class="text-uppercase">Standard</h4>
                                    <h5 class="card-title pricing-card-title">
                                        <span class="align-top">$</span>199

                                    </h5>
                                    <p>We help you to grow up your business and solution for your impressive projects.</p>
                                    <div class="price-button mt-md-3 mt-2">
                                        <a class="btn text-uppercase" href="#contact">
                                            Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="col-md-4 price-main text-center mb-4">
                            <div class="pricing-grid card">
                                <div class="card-body">
                                    <span class="fa fa-file-video-o" aria-hidden="true"></span>
                                    <h4 class="text-uppercase">Premium</h4>
                                    <h5 class="card-title pricing-card-title">
                                        <span class="align-top">$</span>399

                                    </h5>
                                   <p>We help you to grow up your business and solution for your impressive projects.</p>
                                    <div class="price-button mt-md-3 mt-2">
                                        <a class="btn text-uppercase" href="#contact">
                                            Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
    </section>-->
    <!-- //plans -->


<!-- //text -->
<!-- testimonials -->

<!-- //Contact page -->

<!-- footer -->
<!--
<footer class="py-md-5 py-3">
	<div class="container py-md-5 py-3">
		<div class="row footer-grids">
			<div class="col-lg-3 col-sm-6 mb-lg-0 mb-sm-5 mb-4">
				<h4 class="mb-4">Promote</h4>
				<p class="mb-3">Onec Consequat sapien ut cursus rhoncus. Nullam dui mi, vulputate ac metus semper quis luctus sed.</p>
				
			</div>
			<div class="col-lg-3 col-sm-6 mb-md-0 mb-sm-5 mb-4">
				<h4 class="mb-4">Address Info</h4>
				<p><span class="fa mr-2 fa-map-marker"></span>6d canal street TT 3356 <span>Newyork.</span></p>
				<p class="phone py-2"><span class="fa mr-2 fa-phone"></span> +1(12) 123 456 789 </p>
				<p><span class="fa mr-2 fa-envelope"></span><a href="mailto:info@example.com">info@example.com</a></p>
			</div>
			<div class="col-lg-2 col-sm-6 mb-lg-0 mb-sm-5 mb-4">
				<h4 class="mb-4">Quick Links</h4>
				<ul>
					<li><a href="#register">Register here </a></li>
					<li class="my-2"><a href="#team">Business Team</a></li>
					<li><a href="#contact">Support Helpline</a></li>
					<li class="mt-2"><a href="#">Privacy Policy</a></li>
				</ul>
			</div>
			<div class="col-lg-4 col-sm-6">
				<h4 class="mb-4">Subscribe Us</h4>
				<p class="mb-3">Subscribe to our newsletter</p>
				<form action="#" method="post" class="d-flex">
					<input type="email" id="email" name="EMAIL" placeholder="Enter your email here" required="">
					<button type="submit" class="btn">Subscribe</button>
				</form>
			</div>
		</div>
	</div>
</footer>-->
<!-- //footer -->

<!-- copyright -->
<!--<div class="copyright">
	<div class="container py-4">
		<div class=" text-center">
			<p>© 2019 promote. All Rights Reserved | Design by <a href="http://w3layouts.com/"> W3layouts</a> </p>
		</div>
	</div>
</div>-->
<!-- //copyright -->
		
<!-- move top -->
<!--
<div class="move-top text-right">
	<a href="#home" class="move-top"> 
		<span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
	</a>
</div>-->
<!-- move top -->



</body>
</html>