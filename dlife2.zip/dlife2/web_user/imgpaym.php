 
 
<?php

include("../connection.php");
session_start();


$abcd=$_GET['product_id'];

//$itemname=$_GET['itemname'];

//$price=$_SESSION['price'];
//echo "<script>alert($item_id);</script>";
//$amount=$_SESSION['amount'];
 

?>

<style>


body
{
<body background="regcustomer.jpg">
}
.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 8px 6px;
  text-decoration: none;
  font-size: 20px;
	
width:10%;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

h2 

  {
    color: tomato;
    text-align: center;
    
	margin-top:80px;
	margin-bottom:80px;

   }
h1{
	color:white;
}

.img{
	width:180px;
	height:50px;
    }
.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
ul li{
float:left;
width:250px;
height:50px;

opacity:.9;
line-height:10px;
text-align:center;
font-size:20px;
margin-right:400px;
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}



input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
body {
  margin: 10%;
  padding: 0;
   background-image: url("table.jpg");
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 800;
}


input[type=text],[type=date],[type=radio],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}


input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 20px;
    margin-left:400px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}


/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body >

<h1><a href="inlogin.php">HOME</a></h1>
<div class="container">

<fieldset>
 <form name="myForm" action="total.php" autocomplete="off"

   onsubmit="return validateForm()" method="post">


     

	  


 

</div>
  </div>

 


   
<?php	
  $obj=new db();
$selec="select * from product WHERE product_id=$abcd";
$data1=$obj->execute($selec);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data1)>0)
{

while($row=mysqli_fetch_array($data1))
{
$product=$row['product'];	
$price=$row['price'];


?>
<div class="row">
     <div class="col-25">
        <label for="price">ITEM:</label>
		 </div>
		 <div class="col-75">
        <input type="text"  name="itemname"  readonly  value="<?php echo $product;?>" required="">
      </div>
	  </div>
	  

	<div class="row">
     <div class="col-25">
        <label for="price">PRICE:</label>
		 </div>
		 <div class="col-75">
        <input type="text"  name="price"  readonly  value="<?php echo $price;?>" required="">
      </div>
	  </div>
	  
	  
	

	  
	  
     
 
	  
	  
 <?php
 }
 

}
?>
<br><br><button  type="submit" name="submit" id="">BUY NOW </button> </td>

</fieldset>
</body>
</form>



<html>