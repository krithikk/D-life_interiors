
<?php
include 'conn.php';


?>

<body background="images/table.jpg">



<table width="1236" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <ul><h1><a href="userhome.php">HOME</a>
</ul>
  <tr>
    <td width="800" height="363"></td>
    <td width="366" valign="top"><div align="center">
   <br><br> <br><br> <h1> <p>EDIT YOUR PROFILE </p></h1>
      <form name="form1" method="post" action="editprofile1.php">
	  
	    <?php
	  session_start();
	  include("../connection.php");
$Lid=$_SESSION['lid'];
if($Lid>0)
{
	
	$obj=new db();
	$select="select * from register where login_id='$Lid'";
	$data=$obj->execute($select);
	$row=mysqli_fetch_array($data);
	?>
	   
	  
        <table width="238" border="1">
          
          <tr>
            <td>NAME</td>
            <td><input name="name" type="text" value="<?php echo $row['name'];?>" id="name"></td>
          </tr>
		  
          <tr>
            <td>Email</td>
            <td><input name="email" type="text" value="<?php echo $row['email'];?>" id="email"></td>
          </tr>
          <tr>
		  
            
		   <tr>
            <td>PHONE</td>
            <td><input name="phone" type="text" id="phone" value="<?php echo $row['phone'];?>"></td>
          </tr>
          
            <!-- <tr>
            <td>Gender</td>
            <td><input type="radio" name="gender" value="m" checked>Male
            <input type="radio" name="gender" value="f">Female</td></tr>
          </tr>
          <tr>
            <td>Mobno</td>
            <td><input name="mobno" type="text" id="mobno" value="<?php echo $row['mobno'];?>"></td>
          </tr>
          <tr>
            <td>Pincode</td>
            <td><input name="pincode" type="text" id="pincode" value="<?php echo $row['pincode'];?>"></td>
          </tr>
          <tr>
            <td>Housename</td>
            <td><input name="hname" type="text" id="hname" value="<?php echo $row['hname'];?>"></td>
          </tr>
         <td>Street</td>
            <td><input name="street" type="text" id="street" value="<?php echo $row['street'];?>"></td>
          </tr>
		 
		 </tr>
         <td>Locality</td>
            <td><input name="locality" type="text" id="locality" value="<?php echo $row['locality'];?>"></td>
          </tr>
		  <tr><td>District</td><td>
<select name="did" id="did">

							<option value="district">District</option>
							<?php 
							 while($r=mysqli_fetch_array($sq))  
							 {
							?>
                    <option value="<?php echo $r['did'];
					?>">
					<?php echo $r['districtname']?> 
					<?php
							 }
                      ?>				
							</select>
							</tr>
							<tr>
            <td>state</td>
            <td><input name="state" type="text" id="state" value="<?php echo $row['state'];?>"></td>
          </tr>
		  -->
		  
          <tr>
            <td colspan="2"><div align="center">
                <input type="submit" name="submit" value="submit" id="submit">
                <!--<input type="reset" name="Submit2" value="Reset">-->
            </div></td>
            </tr>
        </table>
		
<?php
}
?>

        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form>
      <p>&nbsp;</p>
    </div></td>
    <td width="579"></td>
  </tr>
  <tr>
    <td height="13"></td>
    <td></td>
    <td></td>
  </tr>
</table>




<?php
include "conn.php";
	 
if(isset($_POST['submit']))
{
$email=	$_POST["email"];
$s1=$_POST["name"];
	  
$s6=$_POST["phone"];
	  
	 
$re= mysqli_query($con,"select * from register where email='$email'");


if(mysqli_num_rows($re)>0)
{

	
	mysqli_query($con,"update register SET name='$s1',phone='$s6'where email='$email'");
	
	?>
		<script>
		alert("successfully updated")
		</script>
		<?php
	
}
else
{
	mysqli_error($con);
	?>
    
    <script>
	alert("Invalid username!!!")
	</script>    
    <?php }
}
?>




</body>
</html>
