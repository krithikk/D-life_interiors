<?php
  include("../connection.php");
  include("check_session.php");

?>
<?php
include ("dbconnect.php");
$se="select * from product join category where product.category_id=category.category_id";
$r=mysqli_query($con,$se);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Moopans Oil Mill</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">

    <style type="text/css">
    th{
      width: 150px;
      height: 50px;
      background-color:#82ae46;
      color: white;

    }
    td{
      width: 150px;
      height: 30px;
      
    }
    th,td{
      text-align: left;
      padding: 8px;
    }
    
  </style>
    
   
  </head>
  <body class="goto-here">
        
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
        <div class="container">
          <a class="navbar-brand" href="index.html">MOOPANS OIL MILL</a>
          <!--<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
          </button>-->
          <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item"><a href="user.php" class="nav-link">Home</a></li>
              
              <!-- <li class="nav-item active"><a href="contact.html" class="nav-link">Contact</a></li> -->

            </ul>
          </div>
        </div>
      </nav>
       
      <table  class="align-center"style=" margin-top: 100px; text-align: center;margin-left: auto;margin-right: auto;border-collapse: collapse;width: 50%;">
  <tr class="align-center" style="color: white;font-size:15px; ">
  <th>product</th>
  <th>Category</th>
  <th>description</th> 
  <th>Image</th>
  <th>Buy</th>
  </tr>
  
<?php
while($row=mysqli_fetch_array($r))  
 {
?>
<tr>
<td style="font-size: 15px;"> 
  
   <?php 
        echo $row['product_id'];
       /* $_SESSION['product_id'] =  $row['product_id'];*/
        
    ?>
  </td>
  <td style="font-size: 15px;"> 
   <?php 
        echo $row['categoryname'];
    ?>
  </td>
  <td style="font-size: 15px;">
<?php
echo $row['image'];
?>
<img src="../Admin/upload/<?php echo $row['picture']; ?>" width="150" height="100">

</td>
  
 <!-- <?php
   echo '  
                         
  <td>  
  <img src="../team reg/upload/jpeg;base64,'.base64_encode($row['picture'] ).'" height="300" width="300" class="img-thumnail" /> 
 
  </td>  
                          
  ';?>-->
  <td>
    <form action="cartsample.php" method="POST" >
      <input type="hidden" name="id" value="<?php echo $row['product_id']; ?>"/>
      <input type="submit" value="BUY" class="btn btn-primary py-3 px-5">
    </form>
     
  </td>
 </tr>
 <?php
}
?>
</table>

</body>
</html>