<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
  include("../connection.php");
  include("check_session.php");
  $id=$_GET['id'];
echo $id;
$sel="SELECT * FROM product where product_id=$id";
	$obj=new db();
	$select=$obj->execute($sel);
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Products View</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="Promote Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <!-- //Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	  <link rel="stylesheet" href="css/slider.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <!-- font-awesome-icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
   <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!-- //Fonts -->
	
	<style>
.buttons {
  background-color: pink; /* Green */
  border: none;
  color: black;
  padding: 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button3 {border-radius: 8px;}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: blue;
  padding: 1px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
<body>
   <!-- header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="userhome.php"><span class="fa fa-rocket"></span> D'LIFE </a></h1>
			</div>

			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
				<li class="active"><a href="userhome.php">Home</a></li>
				<li class=""><a href="#about">About Us</a></li>
			
				<li><a class="" href="t.php">Products Categories</a>
				
            
			
 
 
   
   <!--<ul>
   
  

 
              
            </ul>
          </li>-->
		  <li><a class="drop" href="#">Profile</a>
            <ul>
			        <li class=""><a href="profile.php"> View Profile</a></li>
					<li><a class="" href="editprofile1.php">Edit Profile</a>
					
					</ul>
				<li><a class="drop" href="#">Account</a>
            <ul>
              
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>
				
				
				<li class="last-grid"><a href="logout.php">Logout</a></li>
				</ul>
			</ul>
		</nav>
		<!-- //nav -->
	</div>
	<style>
.tkvsoft ul {
	position: absolute;
	
	z-index:9;

	opacity: 0;
	
	background: #fff;

	-webkit-border-radius: 0 0 5px 5px;
	-moz-border-radius: 0 0 5px 5px;
	border-radius: 0 0 5px 5px;

	-webkit-transition: opacity .25s ease .1s;
	-moz-transition: opacity .25s ease .1s;
	-o-transition: opacity .25s ease .1s;
	-ms-transition: opacity .25s ease .1s;
	transition: opacity .25s ease .1s;
}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;

	-webkit-transition: height .25s ease .1s;
	-moz-transition: height .25s ease .1s;
	-o-transition: height .25s ease .1s;
	-ms-transition: height .25s ease .1s;
	transition: height .25s ease .1s;
}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
}

.tkvsoft ul li a {
	width: 200px;
	padding:40px;
	margin: 0;

	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }
</style>

</header>
<!-- //header -->


<!-- banner -->
<div class="vm-product-container">

														<div class="vm-product-media-container">
															<div class="main-image">
																<!--<a  rel='vm-additional-images' href="#">-->
																<img src="../Admin/upload/<?php echo $row['picture']; ?>" height="300" width="300" />
																<!--</a>-->		
															<div class="clear"></div>
															</div>
														</div>

														<div class="vm-product-details-container">

        													<h1 class="product_price" itemprop="name"><?php echo $row['product']; ?>
        													
        													</h1>
    
    	
															
															<br>
		
        													
	    													<div class="spacer-buy-area">

		
																<div class="product-price" id="productPrice3" data-vm="product-prices">
																	<span class="price-crossed" ></span>
																	<div class="PricesalesPrice vm-display vm-price-value">
																		<span class="vm-price-desc"> Price 
																		</span>
																		<span class="PricesalesPrice">$&nbsp<?php echo $row['price']; ?>
															
																		</span>
																	</div>
																	<div class="PricediscountAmount vm-nodisplay">
																		<span class="vm-price-desc">Discount </span>
																		<span class="PricediscountAmount"></span>
																	</div>
																	<div class="PricetaxAmount vm-nodisplay">
																		<span class="vm-price-desc">Tax amount </span>
																		<span class="PricetaxAmount"></span>
																	</div>
																</div> 
																<div class="clear"></div>	
																<div class="addtocart-area">
																	<form method="post" class="product js-recalculate" action="purchasedetails.php" autocomplete="off" >
																		<div class="vm-customfields-wrap">
																		</div>			
				
    																			
    																	<input type="hidden" name="option" value="com_virtuemart"/>
																		<input type="hidden" name="view" value="cart"/>
																		<input type="hidden" name="virtuemart_product_id[]" value="3"/>
																		<input type="hidden" name="pname" value="White Cheese"/>
																		<input type="hidden" name="pid" value="3"/>
																		<input type="hidden" name="Itemid" value="151"/>		

	

																		<hr>
																		<script type="text/javascript" src="../../../s7.addthis.com/js/300/addthis_widget.js#pubid=ra-59b8e576bf14d5a3"></script>
		<!--<div class="share">Share this product:</div>
		<div class="addthis_inline_share_toolbox"></div>-->
		

	    										
	    																<div>
	    																	<label>Which packaging type do u prefer</label>
																			<select name="cat" class="form-control" id="cat"> 
					        													<option value="category">Packaging Type</option> 
																			      <?php
																			      $que="select package from tb_package where status='1'";
																			  $obj=new db();
																			  $queee=$obj->execute($que);

																			          if(mysqli_num_rows($queee)>0)
																			          {
																			          while($rows=mysqli_fetch_array($queee))
																			          { 
																			                //echo "<option value='$rows[1]'> $rows[1] </option>";
																			            echo "<option value='" . $rows[0] ."'>" . $rows[0] ."</option>";
																			          }
																			        }
																			      
																			      ?>
					 														</select>
																		</div>
																		<div>
																			<br>
						    												<label>Which delivery type do u prefer</label>
																			<select name="cat" class="form-control" id="cat"> 
					        													<option value="category">Delivery Type</option> 
																			      <?php
																			      $que="select deliverytype from tb_deliverytype where status='1'";
																			  $obj=new db();
																			  $queee=$obj->execute($que);

																			          if(mysqli_num_rows($queee)>0)
																			          {
																			          while($rows=mysqli_fetch_array($queee))
																			          { 
																			                //echo "<option value='$rows[1]'> $rows[1] </option>";
																			            echo "<option value='" . $rows[0] ."'>" . $rows[0] ."</option>";
																			          }
																			        }
																			      
																			      ?>
					 														</select>
																		</div>
																		<div class="addtocart-bar">
																			<br>
																			<br>
																			<label>Enter period or time for</label>
																			<br>
																			<span class="quantity-box">
																				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
					                       data-errStr="You can buy this product only in multiples of %s pieces!"
					                       value="1" init="1" step="1"  />
																			</span>
																			<span class="quantity-controls js-recalculate">
																				<input type="button" class="quantity-controls quantity-plus"/>
																				<input type="button" class="quantity-controls quantity-minus"/>



																			</span>
																			<span class="addtocart-button">
																				<input type="submit" name="addtocart" id="addtocart" class="addtocart-button" value="Buy Now" title="Add to Cart"  onclick="window.location='purchasedetails.php?id= <?php echo $row['product_id']; ?>';"/>


																						</span>     



																			<span class="addtocart-button">
									                						
									
																				
																				<input type="submit" name="addtocart" id="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" onclick="window.location='cartaction.php?id= <?php echo $row['product_id']; ?>';"/>
									                						</span>
								
																		</div>
																	
																	</form>
																</div>
															</div>
														</div>
										
														<div class="clear"></div>


   													</div>

	        										<div class="product-description" >
	    												<span class="title">Description</span>
					    								<hr>
														<p><?php echo $row['descr']; ?><!--White cheese is a brined curd white cheese made from cow's milk or from goat's milk. The aging time of white cheese is minimum 3 month, it is commonly produced in blocks and has a slightly grainy texture. White cheese is used as a table cheese, in salads (e.g. the Shopska salad) and pastries such as spinach pie and cheese pie. It can also be served cooked or grilled, as part of a sandwich, in omelettes, or as a salty alternative to other cheeses in a variety of dishes.-->
							
														</p>
															
														       
													</div>
													<div class="product-fields">
							<!--<div class="product-field product-field-type-X">
														<span class="product-fields-title-wrapper"><span class="product-fields-title"><strong>Nutrition Facts</strong></span>
											</span>
									<div class="product-field-display"><ul>
					<li>Serving Size: 100gr</li>
					<li>Servings per Container: 3</li>
					<li>Calories: 395</li>
					<li>Calories From Fat: 250</li>
					</ul></div>			</div>-->
														

							      						<div class="clear"></div>
													</div>

					
				</div>
				<!-- //banner slider-->
			</div>
		</div>
	</div>
</div>
<!--<style>
body {
	background-image: url("images/table.jpg");
	height:1000px;
	
}
</style>-->

<!-- //banner -->
<!-- about -->

<!-- //Projects -->
<!-- /plans -->
   <!-- <section class="plans-sec py-5" id="plans">
        <div class="container py-md-5 py-3">
		<h5 class="heading mb-2"> Exclusive prices</h5>
		<h3 class="heading mb-sm-5 mb-3">We Provide Best price</h3>
                    <div class="row pricing-plans">
                        <div class="col-md-4 price-main text-center mb-4">
                            <div class="pricing-grid card">
                                <div class="card-body">
                                    <span class="fa fa-user-o" aria-hidden="true"></span>
                                    <h4 class="text-uppercase">Basic</h4>
                                    <h5 class="card-title pricing-card-title">
                                        <span class="align-top">$</span>199

                                    </h5>
                                   <p>We help you to grow up your business and solution for your impressive projects.</p>
                                    <div class="price-button mt-md-3 mt-2">
                                        <a class="btn text-uppercase" href="#contact">
                                            Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 price-main price-main1  text-center mb-4">
                            <div class="pricing-grid card">
                                <div class="card-body">
                                    <span class="fa fa-female" aria-hidden="true"></span>
                                    <h4 class="text-uppercase">Standard</h4>
                                    <h5 class="card-title pricing-card-title">
                                        <span class="align-top">$</span>199

                                    </h5>
                                    <p>We help you to grow up your business and solution for your impressive projects.</p>
                                    <div class="price-button mt-md-3 mt-2">
                                        <a class="btn text-uppercase" href="#contact">
                                            Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="col-md-4 price-main text-center mb-4">
                            <div class="pricing-grid card">
                                <div class="card-body">
                                    <span class="fa fa-file-video-o" aria-hidden="true"></span>
                                    <h4 class="text-uppercase">Premium</h4>
                                    <h5 class="card-title pricing-card-title">
                                        <span class="align-top">$</span>399

                                    </h5>
                                   <p>We help you to grow up your business and solution for your impressive projects.</p>
                                    <div class="price-button mt-md-3 mt-2">
                                        <a class="btn text-uppercase" href="#contact">
                                            Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
    </section>-->
    <!-- //plans -->


<!-- //text -->
<!-- testimonials -->

<!-- //Contact page -->

<!-- footer -->
<!--
<footer class="py-md-5 py-3">
	<div class="container py-md-5 py-3">
		<div class="row footer-grids">
			<div class="col-lg-3 col-sm-6 mb-lg-0 mb-sm-5 mb-4">
				<h4 class="mb-4">Promote</h4>
				<p class="mb-3">Onec Consequat sapien ut cursus rhoncus. Nullam dui mi, vulputate ac metus semper quis luctus sed.</p>
				
			</div>
			<div class="col-lg-3 col-sm-6 mb-md-0 mb-sm-5 mb-4">
				<h4 class="mb-4">Address Info</h4>
				<p><span class="fa mr-2 fa-map-marker"></span>6d canal street TT 3356 <span>Newyork.</span></p>
				<p class="phone py-2"><span class="fa mr-2 fa-phone"></span> +1(12) 123 456 789 </p>
				<p><span class="fa mr-2 fa-envelope"></span><a href="mailto:info@example.com">info@example.com</a></p>
			</div>
			<div class="col-lg-2 col-sm-6 mb-lg-0 mb-sm-5 mb-4">
				<h4 class="mb-4">Quick Links</h4>
				<ul>
					<li><a href="#register">Register here </a></li>
					<li class="my-2"><a href="#team">Business Team</a></li>
					<li><a href="#contact">Support Helpline</a></li>
					<li class="mt-2"><a href="#">Privacy Policy</a></li>
				</ul>
			</div>
			<div class="col-lg-4 col-sm-6">
				<h4 class="mb-4">Subscribe Us</h4>
				<p class="mb-3">Subscribe to our newsletter</p>
				<form action="#" method="post" class="d-flex">
					<input type="email" id="email" name="EMAIL" placeholder="Enter your email here" required="">
					<button type="submit" class="btn">Subscribe</button>
				</form>
			</div>
		</div>
	</div>
</footer>-->
<!-- //footer -->

<!-- copyright -->
<!--<div class="copyright">
	<div class="container py-4">
		<div class=" text-center">
			<p>© 2019 promote. All Rights Reserved | Design by <a href="http://w3layouts.com/"> W3layouts</a> </p>
		</div>
	</div>
</div>-->
<!-- //copyright -->
		
<!-- move top -->
<!--
<div class="move-top text-right">
	<a href="#home" class="move-top"> 
		<span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
	</a>
</div>-->
<!-- move top -->



</body>
</html>