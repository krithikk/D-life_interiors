
 <!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
  //include("../connection.php");
  include("check_session.php");

?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>User Home</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="Promote Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <!-- //Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	  <link rel="stylesheet" href="css/slider.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <!-- font-awesome-icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
   <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!-- //Fonts -->
</head>
<body>
   <!-- header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="userhome.php"><span class="fa fa-rocket"></span> D'LIFE </a></h1>
			</div>

			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
				<li class="active"><a href="userhome.php">Home</a></li>
				
				<li><a class="drop" href="t.php">Products Categories</a>
            
          </li>
				
				<!--<li><a class="drop" href="#">Account</a>
            <ul>
              <li class=""><a href="profile.php">My Profile</a></li>
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>-->
				<li><a class="drop" href="#">Profile</a>
            <ul>
			        <li class=""><a href="profile.php"> View Profile</a></li>
					<li><a class="" href="editprofile1.php">Edit Profile</a>
					
					</ul>
				<li><a class="drop" href="#">Account</a>
            <ul>
              
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>
				
				<li class="last-grid"><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
		<!-- //nav -->
	</div>
</header>
<!-- //header -->


<!-- banner -->
<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="banner-text-w3pvt">
				<!-- banner slider-->
				<div class="csslider infinity" id="slider1">
					<input type="radio" name="slides" checked="checked" id="slides_1" />
					<input type="radio" name="slides" id="slides_2" />
					<input type="radio" name="slides" id="slides_3" />
					<ul class="banner_slide_bg">
						<li>
							
						</li>
						
					</ul>
					
				</div>
				<!-- //banner slider-->
			</div>
		</div>
	</div>
</div>

<?php
//session_start();
include("../connection.php");
$Lid=$_SESSION['lid'];
if($Lid>0)
{
	
	$obj=new db();
	$select="select * from register where login_id='$Lid'";
	$data=$obj->execute($select);
	$row=mysqli_fetch_array($data);
	?>
	<br><br>
	<center>
	<table border="1" style="width:50%">
	<tr>
	
	<th><label>Name</label></th>
	<td><?php echo $row['name'];?></td>
	</tr>
	
	<th><label>Email</label></th>
	<td><?php echo $row['email'];?></td>
	</tr>
	
	<tr>
	<th><label>Phone</label></th>
	<td><?php echo $row['phone'];?></td>
	</tr>
	
	
	<!--<tr>
	<td colspan="2"><div align="center">
	<a href="editprofile1.php?" id=<?php echo $row['login_id'];?>">Edit</a>
	</div>
	</td>
	</tr>-->

	

	

<?php 
}	
?>



<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>



 <!--
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>Password Change</title>
     </head>
    <body>
    <h1>Change Password</h1>
   <form method="POST" action="changepasswords.php">
    <table>
    <tr>
   <td>Enter your Email</td>
    <td><input type="email" size="10" id="email1" name="email1"></td>
    </tr>
    
  <tr>
    <td>Enter your new password:</td>
    <td><input type="password" size="10" name="newpassword" id="newpassword"></td>
    </tr>
    <tr>
   <td>Re-enter your new password:</td>
   <td><input type="password" size="10" name="confirmnewpassword" id="confirmnewpassword"></td>
    </tr>
    </table>
    <p><input type="submit"  name="submit" value="Update Password">
    </form>
   <p><a href="HOME1.php">Home</a>
   <p><a href="logout.php">Logout</a>
   </body>
    </html> -->



<!--<center><center>
<div align="center">
<div class="container">

 <form name="myForm"  method="post"  autocomplete="off"

 
   onsubmit="return validateForm()" method="post">
   
   
  
  

		
</div>-->


	</table>
	</center>
	</body>
    </html>
