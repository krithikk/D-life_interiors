<?php
  include("../connection.php");
  //include("check_session.php");

?>
<?php
include('dbconnect.php');
$pid=$_POST['id'];
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Products View</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="Promote Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <!-- //Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	  <link rel="stylesheet" href="css/slider.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <!-- font-awesome-icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
   <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!-- //Fonts -->
	
	<style>
.buttons {
  background-color: pink; /* Green */
  border: none;
  color: black;
  padding: 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button3 {border-radius: 8px;}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: blue;
  padding: 1px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
<body>
   <!-- header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="userhome.php"><span class="fa fa-rocket"></span> D'LIFE </a></h1>
			</div>

			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
				<li class="active"><a href="userhome.php">Home</a></li>
				<li class=""><a href="#about">About Us</a></li>
			
				<li><a class="" href="t.php">Products Categories</a>
				
            
			
 
 
   
   <!--<ul>
   
  

 
              
            </ul>
          </li>-->
		  <li><a class="drop" href="#">Profile</a>
            <ul>
			        <li class=""><a href="profile.php"> View Profile</a></li>
					<li><a class="" href="editprofile1.php">Edit Profile</a>
					
					</ul>
				<li><a class="drop" href="#">Account</a>
            <ul>
              
              <li class=""><a href="#services">Services</a></li>
              <li class=""><a href="#portfolio">Portfolio</a></li>
			  <li class=""><a href="#contact">Contact</a></li>
			  <li class=""><a href="changepasswords.php">Change Password</a></li>
			  </ul>
				
				
				<li class="last-grid"><a href="logout.php">Logout</a></li>
				</ul>
			</ul>
		</nav>
		<!-- //nav -->
	</div>
	<style>
.tkvsoft ul {
	position: absolute;
	
	z-index:9;

	opacity: 0;
	
	background: #fff;

	-webkit-border-radius: 0 0 5px 5px;
	-moz-border-radius: 0 0 5px 5px;
	border-radius: 0 0 5px 5px;

	-webkit-transition: opacity .25s ease .1s;
	-moz-transition: opacity .25s ease .1s;
	-o-transition: opacity .25s ease .1s;
	-ms-transition: opacity .25s ease .1s;
	transition: opacity .25s ease .1s;
}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;

	-webkit-transition: height .25s ease .1s;
	-moz-transition: height .25s ease .1s;
	-o-transition: height .25s ease .1s;
	-ms-transition: height .25s ease .1s;
	transition: height .25s ease .1s;
}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
}

.tkvsoft ul li a {
	width: 200px;
	padding:40px;
	margin: 0;

	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }
</style>

</header>
<!-- //header -->


<!-- banner -->
<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="banner-text-w3pvt">
				<!-- banner slider-->
				<div class="csslider infinity" id="slider1">
					<input type="radio" name="slides" checked="checked" id="slides_1" />
					<input type="radio" name="slides" id="slides_2" />
					<input type="radio" name="slides" id="slides_3" />
					
	  
    <?php
		$query = "select * from product join category on product.category_id=category.category_id where product_id='$pid'";
		
        $r=mysqli_query($con,$query);
        if(mysqli_num_rows($r) > 0){
        	while ($row = mysqli_fetch_array($r)) {
        		
        		$price = $row['price'];
        		$cat = $row['categoryname'];
        		$qty = $row['descr'];
				$pic = $row['picture'];
        		?>

    <form action="cart.php" method="POST">    		
    <section class="ftco-section">
    	<div class="container">
    		<div class="row">
    			
    			 <div class="col-lg-6 mb-5 ftco-animate">
    			     
      
    				<!-- <?php
               echo '  
                <img src="../Admin/upload/jpeg;base64,'.base64_encode($row['picture'] ).'" height="300" width="300" class="img-thumnail" /> 
     ';?>	  -->
	 <img src="../Admin/upload/<?php echo $row['picture']; ?>" width="500" height="500">
    				
    			</div> 
    		   <div class="col-lg-6 product-details pl-md-5 ftco-animate">


    				<!--<p class="product"><span><h3><label>product name</label><input type="title" name="cat" value="<?php echo $cat; ?>" ></span></h3></p>-->
					<p class="price"><span><h3><label>product name</label><input type="title" name="cat" value="<?php echo $cat; ?>"></h3></span></p> 
    				<!--<p class="description"><h3><label>Description</label><input type="text" name="qty" value="<?php echo $qty; ?>"></h3>-->
					<p class="price"><span><h3><label>Description</label><input type="text" name="qty" value="<?php echo $qty; ?>"></h3></span></p> 
    				<br><br>
    				<p class="price"><span><h3><label>price</label><input type="text" name="price" value="<?php echo $price; ?>"></h3></span></p> 
    				<div class="w-100"></div>
							<div class="input-group col-md-6 d-flex mb-3">
	             
	            		
	        
	          	</div>

	          	<div class="w-100"></div>
	          	<div class="col-md-12">
	          		
    			  <form action="../amado/checkout.php" method="POST" > 
      <input type="hidden" name="id" value="<?php echo $row['product_id']; ?>"/>
      <input type="submit" name="submit" value="Booking" class="btn btn-primary py-3 px-5">
    </form>
    			</div>

    		</div>
    	</div>
    				

    		</div>
    	</div>
   
</div>
</section>
</form>

	<?php
         }
        	}
        	?>




  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  </body>
</html>

<!-- <?php
    if(isset($_POST['submit']))
    {
      $a=$_POST['cat'];
      $b=$_POST['qty'];
      $c=$_POST['price'];
      $d=$_POST['description'];
      /*$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));*/
      /*$_SESSION['name']=$a;

      /*$sql="insert into productt(category_id,productt_quantity)values('$a','$b')";*/
      $sql="INSERT INTO `cart` (`category_id`,`product_id`) VALUES ('$a','$b','$c','$d')";
      
      $ch=mysqli_query($con,$sql);
     if($ch)

{
  
  ?>
   <script>

 alert("Added to cart");
// window.location="signinnew.html";

</script>

  <?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($con);
}
}

mysqli_close($con);
?>-->