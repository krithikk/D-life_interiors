<?php
include 'conn.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>
input[type=submit]{
    width: 100%;
	
	text-align: center;
  background-color: #4CAF50;
    padding: 10px 45px;
    margin: 2px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
th{
      width: 50px;
      height: 30px;
      background-color:#4caf50;
      color: white;

    }
    td{
      width: 50px;
      height: 30px;
      

    }
    th,td{
      text-align: left;
      padding: 3px;
    }

</style>


    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
          window.scrollTo(0, 1);
		}



</script>
	
	
	
</head>

<body>

	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="adminlogin.php"><span class="fa fa-gift"></span> ZELSONN </a></h1>
			


<!-- banner -->
<div class="banner" id="home">

<div class="col-lg-6 col-md-6 px-lg-5 px-0">
					<div class="banner-form-w3 ml-lg-7">
						<h3 class="mb-3">Approve new staff</h3>
								


</div>
</div>
</div>

<div class="gtco-section border-bottom" >
		<div class="gtco-container" style="margin-top: -50px;">
			<div class="row">
				<div class="col-md-12">
					

				<div class="row form-group"  style="margin-top: 50px;padding-left: 40px;">
					<?php
$se=" select * from `org1`,`staffregister` WHERE org1.logstatus=0 && org1.loginid=staffregister.loginid";
 $re=mysqli_query($con,$se);
?>
					<table border="1" style="width: 75%;">
						<tr style="height: 40px">
						    
						 
							<th style=" padding-left: 20px;">staffimage</th>
							<th style=" padding-left: 20px;">firstname</th>
							<th style=" padding-left: 20px;">lastname</th>
							<th style=" padding-left: 20px;">Addres</th>
							
							<th style=" padding-left: 20px;">sex</th>
                                                         <th style=" padding-left: 20px;">DOB</th>
							<th style=" padding-left: 20px;">adharno</th>
<th style=" padding-left: 20px;">qualification</th>
<th style=" padding-left: 20px;">certificateimage</th>


							<th style=" padding-left: 20px;">phnno</th>
							<th style=" padding-left: 20px;">approve</th>
							<th style=" padding-left: 20px;">reject</th>

							
						</tr>
						<?php
					
						
							while($row=mysqli_fetch_array($re))
  
 {
					?>
    <tr>
<td style="font-size: 15px;"> 
   <?php 
        echo $row['staffimage'];
    ?>
  </td>
<td style="font-size: 15px;"> 
   <?php 
        echo $row['firstname'];
    ?>
  </td>
  <td style="font-size: 15px;"> 
   <?php 
        echo $row['lastname'];
    ?>
  </td>
<td style="font-size: 15px;">

<?php
echo $row['adress'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['sex'];
?>
</td>
<td style="font-size:15px;">
<?php
echo $row['DOB'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['adharno'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['qualification'];
?>

</td>
<td style="font-size: 15px;">
<?php
echo $row['certificateimage'];
?>
<td style="font-size: 15px;">
<?php
echo $row['phnno'];
?>

<td>

  <form action="approve.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['loginid']; ?>"/>
    <input type="submit" value="Approve">
  </form>
</td>
<td>
  <form action="reject.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['loginid']; ?>"/>
    <input type="submit" value="Reject">
  </form>
  </td>
</tr>
<?php
}
?>
</table>

</body>
</html>



