
$(function() {

	//$("#product_error_message").hide();
	//$("#desc_error_message").hide();
	$("#picture_error_message").hide();
	$("#picture2_error_message").hide();
	//$("#price_error_message").hide();
	//$("#items_error_message").hide();
	$("#cat_error_message").hide();
	//$("#ing_error_message").hide();
	//$("#tags_error_message").hide();

	//var error_product = false;
	//var error_desc = false;
	//var error_password = false;
	var error_picture = false;
	var error_picture2 = false;
	//var error_price = false;
	//var error_items = false;
	var error_cat = false;
	//var error_ing = false;
	//var error_tags = false;
	//var error_address = false;
	var pattern = /^[a-zA-Z]*$/;
		
//first name
	//$("#product").focusout(function() {

		//check_username();
	//alert("error");
		
	//});
	//last name
	//$("#desc").focusout(function() {

	//check_desc();
		//alert("error");
		
	//});
	//picture
	$("#picture").focusout(function() {

		check_picture();
		//alert("err");
		
	});
	
	//picture2
	$("#picture2").focusout(function() {

		check_picture2();
		//alert("error");
	});
	//pass
	//$("#price").focusout(function() {

		//check_price();
		//alert("error");
	//});
	//conf pass

	//$("#items").focusout(function() {

		//check_items();
		//alert("error");
	//});
	
	$("#cat").focusout(function() {

		check_cat();
		//alert("error");
	});
	//$("#ing").focusout(function() {

		//check_ing();
		//alert("error");
	//});
	//$("#tags").focusout(function() {

		//check_tags();
		//alert("error");
	//});
	
	
	
	//firstname
	//function check_username() {
		//var name = $("#product").val();
		//if(name != '')
		//{
			
		//	$("#product_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		//}
		//else
		//{
		//	$("#product_error_message").html("Enter valid product");
		//	$("#product_error_message").show();
		//	error_product = true;
			//$( "#FirstName" ).focus();
		//}
//}
	/*function check_desc() {
		var name = $("#desc").val();
		if(name != '')
		{
			
			$("#desc_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#desc_error_message").html("Enter valid description");
			$("#desc_error_message").show();
			error_desc = true;
			//$( "#FirstName" ).focus();
		}
}*/
function check_picture() {
		

(function($) {
$.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    $('#picture').checkFileType({
        allowedExtensions: ['jpg', 'jpeg', 'png'],
        success: function() {
            //alert('Success');
            $("#picture_error_message").hide();
        },
        error: function() {
            //alert('Error');
            $("#picture_error_message").html("Enter picture with .jpg .jpeg .png format ");
			$("#picture_error_message").show();
			error_picture = true;
        }
    });
		
	});
}
	//last name
	
function check_picture2() {
		(function($) {
$.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    $('#picture2').checkFileType({
        allowedExtensions: ['jpg', 'jpeg', 'png'],
        success: function() {
            //alert('Success');
            $("#picture2_error_message").hide();
        },
        error: function() {
            //alert('Error');
            $("#picture2_error_message").html("Enter picture with .jpg .jpeg .png format");
			$("#picture2_error_message").show();
			error_picture2 = true;
        }
    });
		
	});
	}
	/*function check_price() {
		var name = $("#price").val();
		if(name != '')
		{
			
			$("#price_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#price_error_message").html("Enter price");
			$("#price_error_message").show();
			error_price = true;
			//$( "#FirstName" ).focus();
		}
}
function check_items() {
		var name = $("#items").val();
		var patter = /^[0-9]*$/;
		if(patter.test(name) && name != '')
		{
			
			$("#items_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#items_error_message").html("Enter number of items");
			$("#items_error_message").show();
			error_items = true;
			//$( "#FirstName" ).focus();
		}
}*/
function check_cat() {
		var name = $("#cat").val();
		if(name != 'category')
		{
			
			$("#cat_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#cat_error_message").html("Enter valid category");
			$("#cat_error_message").show();
			error_cat = true;
			//$( "#FirstName" ).focus();
		}
}
 /*function check_ing() {
		var name = $("#ing").val();
		if(name != '')
		{
			
			$("#ing_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#ing_error_message").html("Enter valid ingredients");
			$("#ing_error_message").show();
			error_ing = true;
			//$( "#FirstName" ).focus();
		}
}
function check_tags() {
		var name = $("#tags").val();
		if(name != '')
		{
			
			$("#tags_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#tags_error_message").html("Enter valid tagline");
			$("#tags_error_message").show();
			error_tags = true;
			//$( "#FirstName" ).focus();
		}
}*/


	
	$("#prodad").submit(function() {
		//alert("fd");
		/*error_product = false;
		error_desc = false;*/
		error_picture = false;
		error_picture2 = false;
		/*error_price = false;
		error_items = false;*/
		error_cat = false;
		/*error_ing = false;
		error_tags = false;*/
		/*check_username();
		check_desc();*/
		check_picture();
		check_picture2();
		/*check_price();
		check_items();*/
		check_cat();
		/*check_ing();
		check_tags();*/
		
		//if (error_product === false && error_desc === false && error_picture === false && error_picture2 === false && error_price === false && error_items === false && error_cat === false && error_ing === false && error_tags === false) 
		if (error_picture === false && error_picture2 === false && error_cat === false )
		{
			alert("Success");
			return true;

		}
		else
		{
			alert("Please fill the form correctly");
			return false;
		}
	});
});