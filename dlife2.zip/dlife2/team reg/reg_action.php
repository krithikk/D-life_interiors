<?php
/*require_once('../connection.php');
$name=$_POST['Name'];
$cname=$_POST['designation'];
$emailid=$_POST['Email'];
$username=$_POST['username'];
$password=$_POST['password'];
//$pass=MD5($password);
$sql="insert into teamreg(name,designation,email_id,password) values('$name','$des''$emailid','$username','$password')";
$result=mysqli_query($con,$sql);
if($result)
{
	header("location:../login/login.php");
}

else
{
	echo "failed";
}	
?>*/
include("../connection.php");
 if(isset($_POST['submit']))
 {

$nme =$_FILES['picture']['name'];
////echo $nme;
$temp_name =$_FILES['picture']['tmp_name'];
move_uploaded_file($temp_name,'upload/'.$nme);
 
$name=$_POST['Name'];
//echo $name;
$email=$_POST['Email'];
//echo $email;
$phone=$_POST['Phone'];
//echo $phone;
$quali=$_POST['Qualification'];
//echo $Qualification;
//$img=$_POST['image'];
//echo image;

//$nme=$_FILES['file']['name'];
//$temp_nme=$_FILES['file']['tmp_name'];
//move_uploaded_file($temp_nme,'upload/'.$nme);
//echo $nme;
$pass=$_POST['CreatePassword'];
//echo $pass;




$sql="Insert into login(email,password,status,role,logstatus) values('$email','$pass',1,'team',0)";
$obj=new db();
$obj->execute($sql);
$sel="select login_id from login where email='$email' and password='$pass'";
$login=$obj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";
$lo=$strr[0];

//echo $str['login_id']; or option of above
$sqlll="Insert into teamreg(name,qualification,image,phone,login_id) values('$name','$quali','$nme','$phone',$lo)";
$objj=new db();
$objj->execute($sqlll);
}
 
 header("location:../login/login.php");
?>
