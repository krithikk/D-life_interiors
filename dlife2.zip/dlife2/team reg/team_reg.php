
<!DOCTYPE html>
<html lang="en">
<head>
<script src="js/validate.js">
</script>
<script type="text/javascript" language="javascript" src="javascripts/jquery.js"> </script>
<script type="text/javascript" language="javascript" src="javascripts/script.js"> </script>




    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form for Team</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
     <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="main">
 
<section class="signup">
<div class="container">

			<div class="signup-content">
			
                    <form action="reg_action.php"method="POST"  class="signup-form" name="create_customer" id="create_customer" enctype="multipart/form-data" accept-charset="UTF-8"  >
                        <h2 class="form-title">Sign Up Here..</h2>
                        <div class="form-group">
						<label>Name</label>
                            <input type="text" class="form-input" autocomplete="off" name="Name" id="Name" placeholder="Your Name"  />
							<span id="name_error_message" style="color:red"></span>
                        <div class="form-group">
						<label>Email</label>
                            <input type="email" class="form-input" autocomplete="off" name="Email" id="Email" placeholder="Your Email"  />
							<span id="email_error_message" style="color:red"></span>
                        </div>
						 <div class="form-group">
						 <label>Phone</label>
                            <input type="text" class="form-input" autocomplete="off" name="Phone" id="Phone"   placeholder="Your Contact No" />
							<span id="phone_error_message" style="color:red"></span>
                        </div>
						<div class="form-group" >
						<label> Qualification</label>
						<select name="Qualification" id="Qualification" class="form-input" required=""/>
						<span id="quali_error_message" style="color:red"></span>
						
				<option>--Select--</option> 
				<option value="BArch" >BArch</option>
				<option value="BTech" >BTech</option>
				<option value="BCA">BCA</option>
				<option value="BCOM">BCOM</option>
				</select>
				</div>
				<div class="form-group">
				<label>upload resume</label>
                            <input type="file" class="form-input" autocomplete="off" name="picture" id="picture"  required="" />
							<span id="picture_error_message" style="color:red"></span>
                        </div>
				
                        <div class="form-group">
						<label>Password</label>
                            <input type="password" class="form-input" name="CreatePassword" id="CreatePassword" placeholder="Your Password"   />
							<span id="password_error_message" style="color:red"></span> 
                          </div>
						  <div class="form-group">
						  <label>Confirm Password</label>
                            <input type="password" class="form-input" name="CPassword" id="CPassword"   placeholder=" Confirm Your Password"  />
							<span id="cpassword_error_message" style="color:red"></span>
                          </div>
						 
                        
                        <div class="form-group">
                            <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                            <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="" class="term-service">Terms of service</a></label>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
                        </div>
						<p class="loginhere">
                        Have already an account ? <a href="../login/login.php" class="loginhere-link">Login here   </a>&nbsp;
						<a href="../index.php" > HOME</a>
                    </p>
                    </form>
                    </div>
            </div>
        </section>
		</div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>