<?php
include("features/joomla-virtuemart/connection.php");
  include("check_session.php");
  $sel="SELECT * FROM tb_product WHERE status='1'";
	$obj=new db();
	$select=$obj->execute($sel);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
    
<!-- Mirrored from dhtheme.com/buttermilk/index.php/shop by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Sep 2019 13:50:30 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
                                <!-- head -->
                <base  />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="title" content="Buttermilk - organic dairy products Joomla e-commerce template" />
	<meta name="description" content=".  Read more" />
	<meta name="generator" content="Joomla! - Open Source Content Management" />
	<title>Buttermilk - organic dairy products Joomla e-commerce template</title>
	<link href="shop.html" rel="canonical" />
	<link href="../templates/buttermilk/images/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
	<link href="../templates/buttermilk/css/vm-ltr-commona567.css?vmver=4632b4a7" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/vm-ltr-sitea567.css?vmver=4632b4a7" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/vm-ltr-reviewsa567.css?vmver=4632b4a7" rel="stylesheet" type="text/css" />
	<link href="../components/com_virtuemart/assets/css/chosena567.css?vmver=4632b4a7" rel="stylesheet" type="text/css" />
	<link href="../components/com_virtuemart/assets/css/jquery.fancybox-1.3.4a567.css?vmver=4632b4a7" rel="stylesheet" type="text/css" />
	<link href="http://fonts.googleapis.com/css?family=Catamaran:100,200,300,regular,500,600,700,800,900&amp;subset=latin-ext" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/legacy.css" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/template.css" rel="stylesheet" type="text/css" />
	<link href="../templates/buttermilk/css/presets/preset1.css" rel="stylesheet" type="text/css" class="preset" />
	<link href="../templates/buttermilk/css/frontend-edit.css" rel="stylesheet" type="text/css" />
	<link href="../components/com_sppagebuilder/assets/css/animate.min.css" rel="stylesheet" type="text/css" />
	<link href="../components/com_sppagebuilder/assets/css/sppagebuilder.css" rel="stylesheet" type="text/css" />
	<style type="text/css">
body{font-family:Catamaran, sans-serif; font-weight:normal; }
h1{font-family:Catamaran, sans-serif; font-weight:700; }
h2{font-family:Catamaran, sans-serif; font-weight:700; }
h3{font-family:Catamaran, sans-serif; font-weight:700; }
h4{font-family:Catamaran, sans-serif; font-weight:700; }
h5{font-family:Catamaran, sans-serif; font-weight:700; }
h6{font-family:Catamaran, sans-serif; font-weight:700; }
.sp-megamenu-parent{font-family:Catamaran, sans-serif; font-size:16px; font-weight:700; }
	</style>
	<script type="application/json" class="joomla-script-options new">{"csrf.token":"a89392f302fa4882263609b98e7cec3b","system.paths":{"root":"\/buttermilk","base":"\/buttermilk"},"system.keepalive":{"interval":840000,"uri":"\/buttermilk\/index.php\/component\/ajax\/?format=json"}}</script>
	<script src="../media/jui/js/jquery.min86d6.js?19a092cf799ed6c41792146343f78261" type="text/javascript"></script>
	<script src="../media/jui/js/jquery-noconflict86d6.js?19a092cf799ed6c41792146343f78261" type="text/javascript"></script>
	<script src="../media/jui/js/jquery-migrate.min86d6.js?19a092cf799ed6c41792146343f78261" type="text/javascript"></script>
	<script src="../components/com_virtuemart/assets/js/jquery-ui.mine17e.js?vmver=1.9.2" type="text/javascript"></script>
	<script src="../components/com_virtuemart/assets/js/jquery.ui.autocomplete.html.js" type="text/javascript"></script>
	<script src="../components/com_virtuemart/assets/js/jquery.noconflict.js" type="text/javascript" async></script>
	<script src="../components/com_virtuemart/assets/js/vmsitea567.js?vmver=4632b4a7" type="text/javascript"></script>
	<script src="../components/com_virtuemart/assets/js/chosen.jquery.mina567.js?vmver=4632b4a7" type="text/javascript"></script>
	<script src="../components/com_virtuemart/assets/js/vmpricesa567.js?vmver=4632b4a7" type="text/javascript"></script>
	<script src="../components/com_virtuemart/assets/js/fancybox/jquery.fancybox-1.3.4.packa567.js?vmver=4632b4a7" type="text/javascript"></script>
	<script src="../templates/buttermilk/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../templates/buttermilk/js/jquery.sticky.js" type="text/javascript"></script>
	<script src="../templates/buttermilk/js/main.js" type="text/javascript"></script>
	<script src="../templates/buttermilk/js/frontend-edit.js" type="text/javascript"></script>
	<script src="../components/com_sppagebuilder/assets/js/jquery.parallax.js" type="text/javascript"></script>
	<script src="../components/com_sppagebuilder/assets/js/sppagebuilder.js" type="text/javascript"></script>
	<script src="../media/system/js/core86d6.js?19a092cf799ed6c41792146343f78261" type="text/javascript"></script>
	<!--[if lt IE 9]><script src="/buttermilk/media/system/js/polyfill.event.js?19a092cf799ed6c41792146343f78261" type="text/javascript"></script><![endif]-->
	<script src="../media/system/js/keepalive86d6.js?19a092cf799ed6c41792146343f78261" type="text/javascript"></script>
	<script src="../modules/mod_virtuemart_cart/assets/js/update_carta567.js?vmver=4632b4a7" type="text/javascript"></script>
	<script type="text/javascript">
//<![CDATA[ 
if (typeof Virtuemart === "undefined"){
	var Virtuemart = {};}
var vmSiteurl = '../index.html' ;
Virtuemart.vmSiteurl = vmSiteurl;
var vmLang = '&lang=en';
Virtuemart.vmLang = vmLang; 
var vmLangTag = 'en';
Virtuemart.vmLangTag = vmLangTag;
var Itemid = '&Itemid=102';
Virtuemart.addtocart_popup = "1" ; 
var usefancy = true;
 //]]>

var sp_preloader = '1';

var sp_gotop = '1';

var sp_offanimation = 'fullscreen';

jQuery(function($){ initTooltips(); $("body").on("subform-row-add", initTooltips); function initTooltips (event, container) { container = container || document;$(container).find(".hasTooltip").tooltip({"html": true,"container": "body"});} });
	</script>

                                </head>
                <body class="site com-virtuemart view-category no-layout no-task itemid-102 en-gb ltr  sticky-header layout-fluid off-canvas-menu-init">

                    <div class="body-wrapper">
                        <div class="body-innerwrapper">
                            <div class="sp-pre-loader"><div class="sp-loader-with-logo"><div class="logo"><img src="../templates/buttermilk/images/presets/preset1/logo.png" alt=""></div><div class="line" id="line-load"></div></div></div><section id="sp-toolbar" class=" hidden-xs"><div class="container"><div class="row"><div id="sp-toolbar1" class="col-sm-6 col-md-6"><div class="sp-column "><ul class="sp-contact-info"><li class="sp-contact-phone"><i class="fa fa-phone"></i> <a href="">0700 123 7654</a></li><li class="sp-contact-email"><i class="fa fa-envelope"></i> <a href="">milky@gmail.com</a></li><li class="sp-contact-time"><i class="fa fa-clock-o"></i>Mon - Fri 09:00 - 18:00</li></ul></div></div><div id="sp-toolbar2" class="col-sm-6 col-md-6"><div class="sp-column "><div class="sp-module "><div class="sp-module-content">
<!-- Virtuemart 2 Ajax Card -->
<div class="vmCartModule " id="vmCartModule">

	<div class="total">
			</div>

<div class="total_products">(Cart empty)</div>
<div class="show_cart">
	<i class="fa fa-shopping-basket"></i>&nbsp;</div>

<div class="payments-signin-button" ></div><noscript>
Please wait</noscript>
</div>


</div></div></div></div></div></div></section><header id="sp-header" class="container"><div class="container"><div class="row"><div id="sp-logo" class="col-xs-6 col-sm-3 col-md-4"><div class="sp-column "><div class="logo"><a href="../index.html"><img class="sp-default-logo" src="../templates/buttermilk/images/presets/preset1/logo.png" alt="ButterMilk - Organic Dairy Farm VirtueMart Joomla Template"><img class="sp-retina-logo" src="../templates/buttermilk/images/presets/preset1/logo%402x.png" alt="ButterMilk - Organic Dairy Farm VirtueMart Joomla Template" width="308" height="60"></a></div></div></div><div id="sp-menu" class="col-xs-6 col-sm-9 col-md-8"><div class="sp-column ">			<div class='sp-megamenu-wrapper'>
				<a id="offcanvas-toggler" class="visible-sm visible-xs" href="#"><i class="fa fa-bars"></i></a>
				<ul class="sp-megamenu-parent menu-fade hidden-sm hidden-xs"><li class="sp-menu-item"><a  href="../index-2u.php"  >Home</a></li><li class="sp-menu-item sp-has-child current-item active"><a  href="userhome.php"  >Shop</a>


					<!--<div class="sp-dropdown sp-dropdown-main sp-dropdown-mega sp-menu-center" style="width: 600px;left: -300px;">


					<div class="sp-dropdown-inner"><div class="row"><div class="col-sm-4"><ul class="sp-mega-group"><li class="sp-menu-item sp-has-child"><a class="sp-group-title" href="javascript:void(0);"  >Categories</a>
					<ul class="sp-mega-group-child sp-dropdown-items"><li class="sp-menu-item"><a  href="shop/categories/milk.html"  >Milk</a></li><li class="sp-menu-item"><a  href="shop/categories/cheese.html"  >Cheese</a></li><li class="sp-menu-item"><a  href="shop/categories/butter.html"  >Butter</a></li></ul></li></ul></div><div class="col-sm-8"><div class="sp-module "><div class="sp-module-content">

<div class="custom"  >
	<a href="shop.html"><img src="../images/Demo/elements/categories.png" alt="Milk"></a></div>
</div></div></div></div></div></div>--></li>

<!--

<li class="sp-menu-item"><a  href="about-usu.php"  >About us</a></li><li class="sp-menu-item"><a  href="blogu.php"  >Blog</a></li><li class="sp-menu-item"><a  href="contactu.php"  >Contact</a></li>


-->
<li class="sp-menu-item"><a  href="profile.php"  >Profile</a></li>
<li class="sp-menu-item"></li>
<li class="sp-menu-item"><a  href="logout.php"  >Logout</a></li>
				</ul>			
				</div>
		</div></div></div></div></header><section id="sp-page-title"><div class="row"><div id="sp-title" class="col-sm-12 col-md-12"><div class="sp-column "><div class="sp-page-title"><div class="container"><h2>Shop</h2>
<ol class="breadcrumb">
	<span>You are here: &#160;</span><li><a href="../index-2.html" class="pathway">Home</a></li><li class="active">Shop</li></ol>
</div></div></div></div></div></section><section id="sp-main-body"><div class="container"><div class="row"><div id="sp-component" class="col-sm-9 col-md-9"><div class="sp-column "><div id="system-message-container">
	</div>
 <div class="category-view"> <div class="category_description">
	</div>
	
<div class="browse-view">
<!--
<div class="orderby-displaynumber">
	<div class="floatleft vm-order-list">
		<div class="orderlistcontainer"><div class="title">Sort by</div><div class="activeOrder"><a title=" +/-" href="shop/dirDesc4176.html?keyword=">Sorted Product Name  +/-</a></div><div class="orderlist"><div><a title="Product Name" href="shop/by%2cname4176.html?keyword=">Product Name</a></div><div><a title="Product SKU" href="shop/by%2csku4176.html?keyword=">Product SKU</a></div><div><a title="Category" href="shop/by%2ccategory_name4176.html?keyword=">Category</a></div><div><a title="Manufacturer name" href="shop/by%2cmanufacturer_name4176.html?keyword=">Manufacturer name</a></div><div><a title="Ordering" href="shop/by%2cordering4176.html?keyword=">Ordering</a></div></div></div>			</div>
	<div class="vm-pagination vm-pagination-top">
		<ul class="pagination"><li class="active"><a>1</a></li><li><a class="" href="shop034f.html?start=6" title="2">2</a></li><li><a class="" href="shopbd13.html?start=12" title="3">3</a></li><li><a class="next" href="shop034f.html?start=6" title="&raquo;">&raquo;</a></li><li><a class="" href="shopbd13.html?start=12" title="End">End</a></li></ul>		<span class="vm-page-counter">Page 1 of 3</span>
	</div>
	<div class="floatright display-number">
Results 1 - 6 of 15<br/><select id="limit" name="limit" class="inputbox" size="1" onchange="window.top.location.href=this.options[this.selectedIndex].value">
	<option value="/buttermilk/index.php/shop?limit=6" selected="selected">6</option>
	<option value="/buttermilk/index.php/shop?limit=12">12</option>
	<option value="/buttermilk/index.php/shop?limit=18">18</option>
	<option value="/buttermilk/index.php/shop?limit=24">24</option>
	<option value="/buttermilk/index.php/shop?limit=48">48</option>
	<option value="/buttermilk/index.php/shop?limit=72">72</option>
</select>
</div>

	<div class="clear"></div>
</div> -- end of orderby-displaynumber --
-->
<?php
	if(mysqli_num_rows($select)>0)
   {
   	


?>
		<div class="featured-view">
	  <h4>Featured Products</h4>






				<div class="row">
			
				<?php
					while($row=mysqli_fetch_array($select))
	{
		?>
		

<div class="product vm-col vm-col-3 vertical-separator">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="White Cheese" href="#">
						<img src="web_admin/upload/<?php echo $row['picture']; ?>" alt="white-cheese" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="#" ><?php echo $row['product']; ?></a></h2>
										<p class="product_s_desc">
						<?php echo $row['tags']; ?>										</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice3" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">Rs.<?php echo $row['price']; ?></span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate"  autocomplete="off" id="form" name="form" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            <!-- <label for="quantity3" class="quantity_box">Quantity: </label> -->
            <span class="quantity-box">
				<!--<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />-->
			</span>
			                <span class="quantity-controls js-recalculate">
				<!--<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>-->
			</span>
			<!--<span class="addtocart-button">
				<input type="submit" name="submit" id="submit" class="addtocart-button" value="Details" title="Add to Cart" >        </span> -->
				<div class="vm-details-button" >
				<a href="Details.php?id= <?php echo $row['product_id']; ?>" title="#" class="product-details"><b>Details</b></a>			</div>           
				 <input type="hidden" name="virtuemart_product_id[]" value="3"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="3"/>
			<input type="hidden" name="pname" value="White Cheese"/>
			<input type="hidden" name="pid" value="3"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<!--<a href="#" title="White Cheese" class="product-details">Product details</a>			--></div>
				</div>
	</div>


<!--






		<div class="product vm-col vm-col-3 vertical-separator">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Strawberry Yogurt" href="milk/strawberry-yogurt-detail.html">
						<img src="../images/virtuemart/product/resized/yogurt-strawberry_500x500.jpg" alt="yogurt-strawberry" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="milk/strawberry-yogurt-detail.html" >Strawberry Yogurt</a></h2>
										<p class="product_s_desc">
						Grassmilk Yogurt is a creamy and delicious breakfast made ...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice13" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$3.20</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity13" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="13"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="13"/>
			<input type="hidden" name="pname" value="Strawberry Yogurt"/>
			<input type="hidden" name="pid" value="13"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="milk/strawberry-yogurt-detail.html" title="Strawberry Yogurt" class="product-details">Product details</a>			</div>
				</div>
	</div>

		<div class="product vm-col vm-col-3 ">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Milk 3,6%" href="milk/milk-3-6-detail.html">
						<img src="../images/virtuemart/product/resized/milk_500x500.jpg" alt="milk" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="milk/milk-3-6-detail.html" >Milk 3,6%</a></h2>
										<p class="product_s_desc">
						Simple,pure and clean  ...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice12" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$3.90</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity12" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="12"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="12"/>
			<input type="hidden" name="pname" value="Milk 3,6%"/>
			<input type="hidden" name="pid" value="12"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="milk/milk-3-6-detail.html" title="Milk 3,6%" class="product-details">Product details</a>			</div>
				</div>
	</div>

	    <div class="clear"></div>
  </div>
          <div class="clear"></div>
  </div>
    	<div class="products-view">
	  <h4>Products</h4>
				<div class="row">
			<div class="product vm-col vm-col-3 vertical-separator">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Banana Yogurt" href="milk/banana-yogurt-detail.html">
						<img src="../images/virtuemart/product/resized/yogurt-banana_500x500.jpg" alt="yogurt-banana" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="milk/banana-yogurt-detail.html" >Banana Yogurt</a></h2>
										<p class="product_s_desc">
						Best Yoghort ...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice14" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$3.20</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity14" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="14"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="14"/>
			<input type="hidden" name="pname" value="Banana Yogurt"/>
			<input type="hidden" name="pid" value="14"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="milk/banana-yogurt-detail.html" title="Banana Yogurt" class="product-details">Product details</a>			</div>
				</div>
	</div>

		<div class="product vm-col vm-col-3 vertical-separator">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Bulgarian Yogurt" href="features/joomla-virtuemart/single-product.html">
						<img src="../images/virtuemart/product/resized/yogurt-bulgarian_500x500.jpg" alt="yogurt-bulgarian" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="features/joomla-virtuemart/single-product.html" >Bulgarian Yogurt</a></h2>
										<p class="product_s_desc">
						Best Yoghort...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice15" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$3.30</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity15" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="15"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="15"/>
			<input type="hidden" name="pname" value="Bulgarian Yogurt"/>
			<input type="hidden" name="pid" value="15"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="features/joomla-virtuemart/single-product.html" title="Bulgarian Yogurt" class="product-details">Product details</a>			</div>
				</div>
	</div>

		<div class="product vm-col vm-col-3 ">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Drinking Yogurt" href="milk/drinking-yogurt-detail.html">
						<img src="../images/virtuemart/product/resized/drinking-yogurt_500x500.jpg" alt="drinking-yogurt" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="milk/drinking-yogurt-detail.html" >Drinking Yogurt</a></h2>
										<p class="product_s_desc">
						Best Yoghurt ...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice10" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$2.90</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity10" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="10"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="10"/>
			<input type="hidden" name="pname" value="Drinking Yogurt"/>
			<input type="hidden" name="pid" value="10"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="milk/drinking-yogurt-detail.html" title="Drinking Yogurt" class="product-details">Product details</a>			</div>
				</div>
	</div>

	    <div class="clear"></div>
  </div>
      	<div class="horizontal-separator"></div>
			<div class="row">
			<div class="product vm-col vm-col-3 vertical-separator">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Emmentaler" href="cheese/emmentaler-detail.html">
						<img src="../images/virtuemart/product/resized/ementaler_500x500.jpg" alt="ementaler" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2 class="sppb-social-share-style-solid"><a href="milk/drinking-yogurt-detail.html" >Cheese</a></h2>
										<p class="product_s_desc">
						Buttermilk is small e-commerce Joomla template for organic ...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice6" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$10.50</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity6" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="6"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="6"/>
			<input type="hidden" name="pname" value="Emmentaler"/>
			<input type="hidden" name="pid" value="6"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="cheese/emmentaler-detail.html" title="Emmentaler" class="product-details">Product details</a>			</div>
				</div>
	</div>

		<div class="product vm-col vm-col-3 vertical-separator">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Gouda with Cumin" href="cheese/gouda-with-cumin-detail.html">
						<img src="../images/virtuemart/product/resized/gouda-cumin_500x500.jpg" alt="gouda-cumin" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="cheese/gouda-with-cumin-detail.html" >Gouda with Cumin</a></h2>
										<p class="product_s_desc">
						New taste...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice7" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$9.90</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity7" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="7"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="7"/>
			<input type="hidden" name="pname" value="Gouda with Cumin"/>
			<input type="hidden" name="pid" value="7"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="cheese/gouda-with-cumin-detail.html" title="Gouda with Cumin" class="product-details">Product details</a>			</div>
				</div>
	</div>

		<div class="product vm-col vm-col-3 ">
		<div class="spacer product-container" data-vm="product-container">
			<div class="vm-product-media-container">

					<a title="Grass-Fed Organic Ghee" href="butter/grass-fed-organic-ghee-detail.html">
						<img src="../images/virtuemart/product/resized/ghee_500x500.jpg" alt="ghee" class="browseProductImage" />					</a>

			</div>

			<div class="vm-product-rating-container">
							</div>


				<div class="vm-product-descr-container-1">
					<h2><a href="butter/grass-fed-organic-ghee-detail.html" >Grass-Fed Organic Ghee</a></h2>
										<p class="product_s_desc">
						Ghee ...											</p>
							</div>


						<div class="vm3pr-1"> <div class="product-price" id="productPrice1" data-vm="product-prices">
	<span class="price-crossed" ></span><div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc">Sales price: </span><span class="PricesalesPrice">$11.90</span></div><div class="PricediscountAmount vm-nodisplay"><span class="vm-price-desc">Discount: </span><span class="PricediscountAmount"></span></div><div class="PricetaxAmount vm-nodisplay"><span class="vm-price-desc">Tax amount: </span><span class="PricetaxAmount"></span></div></div>				<div class="clear"></div>
			</div>
						<div class="vm3pr-0"> 	<div class="addtocart-area">
		<form method="post" class="product js-recalculate" action="http://dhtheme.com/buttermilk/index.php/shop" autocomplete="off" >
			<div class="vm-customfields-wrap">
							</div>			
				
    <div class="addtocart-bar">
	            -- <label for="quantity1" class="quantity_box">Quantity: </label> --
            <span class="quantity-box">
				<input type="text" class="quantity-input js-recalculate" name="quantity[]"
                       data-errStr="You can buy this product only in multiples of %s pieces!"
                       value="1" init="1" step="1"  />
			</span>
			                <span class="quantity-controls js-recalculate">
				<input type="button" class="quantity-controls quantity-plus"/>
				<input type="button" class="quantity-controls quantity-minus"/>
			</span>
			<span class="addtocart-button">
				<input type="submit" name="addtocart" class="addtocart-button" value="Add to Cart" title="Add to Cart" />                </span>             <input type="hidden" name="virtuemart_product_id[]" value="1"/>
            <noscript><input type="hidden" name="task" value="add"/></noscript> 
    </div>			<input type="hidden" name="option" value="com_virtuemart"/>
			<input type="hidden" name="view" value="cart"/>
			<input type="hidden" name="virtuemart_product_id[]" value="1"/>
			<input type="hidden" name="pname" value="Grass-Fed Organic Ghee"/>
			<input type="hidden" name="pid" value="1"/>
			<input type="hidden" name="Itemid" value="102"/>		</form>

	</div>

			</div>

			<div class="vm-details-button">
				<a href="butter/grass-fed-organic-ghee-detail.html" title="Grass-Fed Organic Ghee" class="product-details">Product details</a>			</div>
				</div>
	</div> -->
	<?php
}
}
?>


	    <div class="clear"></div>
  </div>
          <div class="clear"></div>
  </div>
    		<!--<div class="vm-pagination vm-pagination-bottom"><ul class="pagination"><li class="active"><a>1</a></li><li><a class="" href="shop034f.html?start=6" title="2">2</a></li><li><a class="" href="shopbd13.html?start=12" title="3">3</a></li><li><a class="next" href="shop034f.html?start=6" title="&raquo;">&raquo;</a></li><li><a class="" href="shopbd13.html?start=12" title="End">End</a></li></ul><span class="vm-page-counter">Page 1 of 3</span></div>-->
	</div>

</div>

<!-- end browse-view -->







<script id="updateChosen-js" type="text/javascript">//<![CDATA[ 
if (typeof Virtuemart === "undefined")
	var Virtuemart = {};
	Virtuemart.updateChosenDropdownLayout = function() {
		var vm2string = {editImage: 'edit image',select_all_text: 'Select all',select_some_options_text: 'Available for all'};
		jQuery("select.vm-chzn-select").chosen({enable_select_all: true,select_all_text : vm2string.select_all_text,select_some_options_text:vm2string.select_some_options_text,disable_search_threshold: 5});
		//console.log("updateChosenDropdownLayout");
	}
	jQuery(document).ready( function() {
		Virtuemart.updateChosenDropdownLayout($);
	}); //]]>
</script>
<script id="vm-countryState-js" type="text/javascript">//<![CDATA[ 
jQuery(document).ready( function($) {
			$("#virtuemart_country_id_field").vm2front("list",{dest : "#virtuemart_state_id_field",ids : "",prefiks : ""});
		}); //]]>
</script>
<script id="vm-countryStateshipto_-js" type="text/javascript">//<![CDATA[ 
jQuery(document).ready( function($) {
			$("#shipto_virtuemart_country_id_field").vm2front("list",{dest : "#shipto_virtuemart_state_id_field",ids : "",prefiks : "shipto_"});
		}); //]]>
</script>

<script id="ready.vmprices-js" type="text/javascript">//<![CDATA[ 
jQuery(document).ready(function($) {

		Virtuemart.product($("form.product"));
}); //]]>
</script>
<script id="vm-hover-js" type="text/javascript">//<![CDATA[ 
jQuery(document).ready(function () {
	jQuery('.orderlistcontainer').hover(
		function() { jQuery(this).find('.orderlist').stop().show()},
		function() { jQuery(this).find('.orderlist').stop().hide()}
	)
}); //]]>
</script>
<script id="popups-js" type="text/javascript">//<![CDATA[ 
jQuery(document).ready(function($) {
		
		$('a.ask-a-question, a.printModal, a.recommened-to-friend, a.manuModal').click(function(event){
		  event.preventDefault();
		  $.fancybox({
			href: $(this).attr('href'),
			type: 'iframe',
			height: 550
			});
		  });
		
	}); //]]>
</script>
</div></div>
<!--<div id="sp-right" class="col-sm-3 col-md-3"><div class="sp-column class2"><div class="sp-module  title9"><h3 class="sp-module-title">Product Search</h3><div class="sp-module-content">--BEGIN Search Box --


	--
<form action="http://dhtheme.com/buttermilk/index.php/shop?search=true" method="get">
<div class="search title9">
<input name="keyword" id="mod_virtuemart_search" maxlength="20" alt="Search" class="inputbox title9" type="text" size="20" value="Product name or SKU"  onblur="if(this.value=='') this.value='Product name or SKU';" onfocus="if(this.value=='Product name or SKU') this.value='';" /><br /><input type="submit" value="Search" class="button title9" onclick="this.form.keyword.focus();"/></div>
		<input type="hidden" name="limitstart" value="0" />
		<input type="hidden" name="option" value="com_virtuemart" />
		<input type="hidden" name="view" value="category" />
		<input type="hidden" name="virtuemart_category_id" value="0"/>

	  </form>-->

<!-- End Search Box -->
</div></div>
<!--<div class="sp-module title8"><h3 class="sp-module-title">Categories</h3><div class="sp-module-content"><ul class="nav menu">
<li class="item-150"><a href="#.html" > Milk</a></li><li class="item-151"><a href="#" > Cheese</a></li><li class="item-152"><a href="#" > Butter</a></li></ul>
</div></div>-->
</div></div>
</div></div></section><section id="sp-bottom-b"><div class="container"><div class="row"><div id="sp-bottom9" class="col-sm-12 col-md-12"><div class="sp-column "><div class="sp-module "><div class="sp-module-content"><div class="mod-sppagebuilder  sp-page-builder" data-module_id="87">
	<div class="page-content">
		<div id="section-id-1502955594868" class="sppb-section " ><div class="sppb-row-overlay"></div><div class="sppb-container-inner"><div class="sppb-row"><div class="sppb-col-md-3" id="column-wrap-id-1502955594869"><div id="column-id-1502955594869" class="sppb-column " ><div class="sppb-column-addons"><div id="sppb-addon-1502955638608" class="clearfix" ><div class="sppb-addon sppb-addon-feature sppb-text-left "><div class="sppb-addon-content sppb-text-center"><div class="sppb-media"><div class="pull-left"><div class="sppb-icon"><span class="sppb-icon-container"><i aria-hidden="true" aria-label="0700 123 456" class="fa fa-truck"></i></span></div></div><div class="sppb-media-body"><div class="sppb-media-content"><h4 class="sppb-addon-title sppb-feature-box-title sppb-media-heading">0700 123 456</h4><div class="sppb-addon-text">				Call our support line.</div></div></div></div></div></div></div></div></div></div><div class="sppb-col-md-4" id="column-wrap-id-1502955638604"><div id="column-id-1502955638604" class="sppb-column " ><div class="sppb-column-addons"><div id="sppb-addon-1502955869992" class="clearfix" ><div class="sppb-addon sppb-addon-feature sppb-text-left "><div class="sppb-addon-content sppb-text-center"><div class="sppb-media"><div class="pull-left"><div class="sppb-icon"><span class="sppb-icon-container"><i aria-hidden="true" aria-label="hq (@) bttmk.com" class="fa fa-envelope"></i></span></div></div><div class="sppb-media-body"><div class="sppb-media-content">
		                        <h4 class="sppb-addon-title sppb-feature-box-title sppb-media-heading">milky@gmail.com</h4><div class="sppb-addon-text">			Send your comments or thoughts.</div></div></div></div></div></div></div></div></div></div><div class="sppb-col-md-3" id="column-wrap-id-1502955638605"><div id="column-id-1502955638605" class="sppb-column " ><div class="sppb-column-addons"><div id="sppb-addon-1502956168115" class="clearfix" ><div class="sppb-addon sppb-addon-feature sppb-text-left "><div class="sppb-addon-content sppb-text-center"><div class="sppb-media"><div class="pull-left"><div class="sppb-icon"><span class="sppb-icon-container"><i aria-hidden="true" aria-label="9:00 - 18:00" class="fa fa-clock-o"></i></span></div></div><div class="sppb-media-body"><div class="sppb-media-content">
		                                          <p>Full Day</p>
	                                          <div class="sppb-addon-text">			Our working hours.</div></div></div></div></div></div></div></div></div></div><div class="sppb-col-md-2" id="column-wrap-id-1502958164475"><div id="column-id-1502958164475" class="sppb-column" ><div class="sppb-column-addons"><div id="sppb-addon-1502958298684" class="clearfix" ><div class="sppb-text-center"><a href="#" id="btn-1502958298684" class="sppb-btn  sppb-btn-custom sppb-btn-lg sppb-btn-block sppb-btn-round">Shop Now</a></div></div></div></div></div></div></div></div><style type="text/css">.sp-page-builder .page-content #section-id-1502960570801{padding:0px 0px 0px 0px;margin:0px 0px 0px 0px;}#sppb-addon-1502960952306 #btn-1502960952306.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502960952306 #btn-1502960952306.sppb-btn-custom { background-color:rgba(77, 112, 168, 1); color:#ffffff;}#sppb-addon-1502960952306 #btn-1502960952306.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}#sppb-addon-1502961127801 {margin:10px 0px 0px 0px;}#sppb-addon-1502961127801 #btn-1502961127801.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502961127801 #btn-1502961127801.sppb-btn-custom { background-color:rgba(0, 187, 242, 1); color:#ffffff;}#sppb-addon-1502961127801 #btn-1502961127801.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}#sppb-addon-1502961303142 {margin:10px 0px 0px 0px;}#sppb-addon-1502961303142 #btn-1502961303142.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502961303142 #btn-1502961303142.sppb-btn-custom { background-color:rgba(227, 64, 29, 1); color:#ffffff;}#sppb-addon-1502961303142 #btn-1502961303142.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}#sppb-addon-1502961303149 {margin:10px 0px 0px 0px;}#sppb-addon-1502961303149 #btn-1502961303149.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502961303149 #btn-1502961303149.sppb-btn-custom { background-color:rgba(203, 55, 55, 1); color:#ffffff;}#sppb-addon-1502961303149 #btn-1502961303149.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}.sp-page-builder .page-content #section-id-1502955594868{padding:0px 0px 0px 0px;margin:0px 0px 0px 0px;}#sppb-addon-1502955638608 .sppb-addon-title {color:rgba(255, 255, 255, 1);font-size:23px;line-height:23px;}#sppb-addon-1502955638608 .sppb-icon .sppb-icon-container {display:inline-block;text-align:center;padding:0;color:rgba(255, 255, 255, 0.3);}#sppb-addon-1502955638608 .sppb-icon .sppb-icon-container > i {font-size:52px;width:52px;height:52px;line-height:52px;}@media (min-width:768px) and (max-width:991px) {#sppb-addon-1502955638608 .sppb-media .sppb-media-body {width:auto;}}@media (max-width:767px) {#sppb-addon-1502955638608 .sppb-media .sppb-media-body {width:auto;}}#sppb-addon-1502955869992 .sppb-addon-title {color:rgba(255, 255, 255, 1);font-size:24px;line-height:24px;}#sppb-addon-1502955869992 .sppb-icon .sppb-icon-container {display:inline-block;text-align:center;padding:0;color:rgba(255, 255, 255, 0.3);}#sppb-addon-1502955869992 .sppb-icon .sppb-icon-container > i {font-size:52px;width:52px;height:52px;line-height:52px;}@media (min-width:768px) and (max-width:991px) {#sppb-addon-1502955869992 .sppb-media .sppb-media-body {width:auto;}}@media (max-width:767px) {#sppb-addon-1502955869992 .sppb-media .sppb-media-body {width:auto;}}#sppb-addon-1502956168115 .sppb-addon-title {color:rgba(255, 255, 255, 1);font-size:24px;line-height:24px;}#sppb-addon-1502956168115 .sppb-icon .sppb-icon-container {display:inline-block;text-align:center;padding:0;color:rgba(255, 255, 255, 0.3);}#sppb-addon-1502956168115 .sppb-icon .sppb-icon-container > i {font-size:52px;width:52px;height:52px;line-height:52px;}@media (min-width:768px) and (max-width:991px) {#sppb-addon-1502956168115 .sppb-media .sppb-media-body {width:auto;}}@media (max-width:767px) {#sppb-addon-1502956168115 .sppb-media .sppb-media-body {width:auto;}}#sppb-addon-1502958298684 #btn-1502958298684.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502958298684 #btn-1502958298684.sppb-btn-custom { background-color:rgba(255, 255, 255, 1); color:rgba(32, 139, 243, 1);}#sppb-addon-1502958298684 #btn-1502958298684.sppb-btn-custom:hover { background-color:rgba(116, 250, 255, 1); color:rgba(32, 139, 243, 1);}</style>	</div>
</div>
</div></div></div></div></div></div></section><section id="sp-bottom-c"><div class="container"><div class="row"><div id="sp-bottom13" class="col-sm-3 col-md-3"><div class="sp-column "><div class="sp-module "><h3 class="sp-module-title">Certificate</h3><div class="sp-module-content">

<div class="custom"  >
	<img src="../images/Demo/elements/certified.png" alt="Certificate"></div>
</div></div></div></div><div id="sp-bottom14" class="col-sm-3 col-md-3"><div class="sp-column "><div class="sp-module "><h3 class="sp-module-title">Site Information</h3><div class="sp-module-content"><ul class="nav menu">
<li class="item-107"><a href="#" > Privacy Policy</a></li><li class="item-108"><a href="#" > Terms &amp; Conditions</a></li><li class="item-109"><a href="#" > Return Policy</a></li><li class="item-110"><a href="#" > Complaints Policy</a></li><li class="item-111"><a href="#" > Delivery Terms</a></li></ul>
</div></div></div></div><div id="sp-bottom15" class="col-sm-3 col-md-3"><div class="sp-column "><div class="sp-module "><h3 class="sp-module-title">Payment Methods</h3><div class="sp-module-content">

<div class="custom"  >
	<img src="../images/Demo/elements/payment-methods.png" alt="Payment Methods"></div>
</div></div></div></div><div id="sp-bottom16" class="col-sm-3 col-md-3"><div class="sp-column "><div class="sp-module "><h3 class="sp-module-title">Follow Us</h3><div class="sp-module-content"><div class="mod-sppagebuilder  sp-page-builder" data-module_id="100">
	<div class="page-content">
		<div id="section-id-1502960570801" class="sppb-section " ><div class="sppb-row-overlay"></div><div class="sppb-container-inner"><div class="sppb-row"><div class="sppb-col-md-12" id="column-wrap-id-1502960570802"><div id="column-id-1502960570802" class="sppb-column" ><div class="sppb-column-addons"><div id="sppb-addon-1502960952306" class="clearfix" ><div class="sppb-text-center"><a target="_blank" href="https://www.facebook.com/" id="btn-1502960952306" class="sppb-btn  sppb-btn-custom sppb-btn-lg sppb-btn-block sppb-btn-round"><i class="fa fa-facebook"></i> Facebook</a></div></div><div id="sppb-addon-1502961127801" class="clearfix" ><div class="sppb-text-center"><a target="_blank" href="https://twitter.com/" id="btn-1502961127801" class="sppb-btn  sppb-btn-custom sppb-btn-lg sppb-btn-block sppb-btn-round"><i class="fa fa-twitter"></i> Twitter</a></div></div><div id="sppb-addon-1502961303142" class="clearfix" ><div class="sppb-text-center"><a target="_blank" href="https://plus.google.com/" id="btn-1502961303142" class="sppb-btn  sppb-btn-custom sppb-btn-lg sppb-btn-block sppb-btn-round"><i class="fa fa-google-plus"></i> Google +</a></div></div><div id="sppb-addon-1502961303149" class="clearfix" ><div class="sppb-text-center"><a target="_blank" href="https://www.youtube.com/" id="btn-1502961303149" class="sppb-btn  sppb-btn-custom sppb-btn-lg sppb-btn-block sppb-btn-round"><i class="fa fa-youtube"></i> YouTube</a></div></div></div></div></div></div></div></div><style type="text/css">.sp-page-builder .page-content #section-id-1502960570801{padding:0px 0px 0px 0px;margin:0px 0px 0px 0px;}#sppb-addon-1502960952306 #btn-1502960952306.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502960952306 #btn-1502960952306.sppb-btn-custom { background-color:rgba(77, 112, 168, 1); color:#ffffff;}#sppb-addon-1502960952306 #btn-1502960952306.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}#sppb-addon-1502961127801 {margin:10px 0px 0px 0px;}#sppb-addon-1502961127801 #btn-1502961127801.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502961127801 #btn-1502961127801.sppb-btn-custom { background-color:rgba(0, 187, 242, 1); color:#ffffff;}#sppb-addon-1502961127801 #btn-1502961127801.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}#sppb-addon-1502961303142 {margin:10px 0px 0px 0px;}#sppb-addon-1502961303142 #btn-1502961303142.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502961303142 #btn-1502961303142.sppb-btn-custom { background-color:rgba(227, 64, 29, 1); color:#ffffff;}#sppb-addon-1502961303142 #btn-1502961303142.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}#sppb-addon-1502961303149 {margin:10px 0px 0px 0px;}#sppb-addon-1502961303149 #btn-1502961303149.sppb-btn-custom{font-weight:bold;}#sppb-addon-1502961303149 #btn-1502961303149.sppb-btn-custom { background-color:rgba(203, 55, 55, 1); color:#ffffff;}#sppb-addon-1502961303149 #btn-1502961303149.sppb-btn-custom:hover { background-color:rgba(36, 36, 36, 0.5); color:#ffffff;}</style>	</div>
</div>
</div></div></div></div></div></div></section><footer id="sp-footer"><div class="container"><div class="row"><div id="sp-footer1" class="col-sm-12 col-md-12"><div class="sp-column "><span class="sp-copyright">© 2018 Your Company. All Rights Reserved. Designed By DHtheme</span></div></div></div></div></footer>                        </div> <!-- /.body-innerwrapper -->
                    </div> <!-- /.body-innerwrapper -->

                    <!-- Off Canvas Menu -->
                    <div class="offcanvas-menu">
                        <a href="#" class="close-offcanvas"><i class="fa fa-remove"></i></a>
                        <div class="offcanvas-inner">
                                                          <div class="sp-module "><div class="sp-module-content"><ul class="nav menu">
<li class="item-101"><a href="../index-2.html" > Home</a></li><li class="item-102  current active deeper parent"><a href="shop.html" > Shop</a><span class="offcanvas-menu-toggler collapsed" data-toggle="collapse" data-target="#collapse-menu-102"><i class="open-icon fa fa-angle-down"></i><i class="close-icon fa fa-angle-up"></i></span><ul class="collapse" id="collapse-menu-102"><li class="item-160  divider deeper parent"><a class="separator ">Categories</a>
<span class="offcanvas-menu-toggler collapsed" data-toggle="collapse" data-target="#collapse-menu-160"><i class="open-icon fa fa-angle-down"></i><i class="close-icon fa fa-angle-up"></i></span><ul class="collapse" id="collapse-menu-160"><li class="item-153"><a href="shop/categories/milk.html" > Milk</a></li><li class="item-154"><a href="shop/categories/cheese.html" > Cheese</a></li><li class="item-155"><a href="shop/categories/butter.html" > Butter</a></li></ul></li></ul></li><li class="item-103"><a href="about-us.html" > About us</a></li><li class="item-104"><a href="blog.html" > Blog</a></li><li class="item-105"><a href="contact.html" > Contact</a></li><li class="item-116  divider deeper parent"><a class="separator ">Features</a>
<span class="offcanvas-menu-toggler collapsed" data-toggle="collapse" data-target="#collapse-menu-116"><i class="open-icon fa fa-angle-down"></i><i class="close-icon fa fa-angle-up"></i></span><ul class="collapse" id="collapse-menu-116"><li class="item-161  divider deeper parent"><a class="separator ">Features</a>
<span class="offcanvas-menu-toggler collapsed" data-toggle="collapse" data-target="#collapse-menu-161"><i class="open-icon fa fa-angle-down"></i><i class="close-icon fa fa-angle-up"></i></span><ul class="collapse" id="collapse-menu-161"><li class="item-165"><a href="features/features/feature-box.html" > Feature Box</a></li><li class="item-169"><a href="features/features/buttons.html" > Buttons</a></li><li class="item-171"><a href="features/features/accordions-tabs.html" > Accordions &amp; Tabs</a></li><li class="item-172"><a href="features/features/progress-bars-pies.html" > Progress Bars &amp; Pies</a></li><li class="item-176"><a href="features/features/pricing-tables.html" > Pricing Tables</a></li><li class="item-179"><a href="features/features/team-testimonials.html" > Team &amp; Testimonials</a></li></ul></li><li class="item-162  divider deeper parent"><a class="separator ">More Features</a>
<span class="offcanvas-menu-toggler collapsed" data-toggle="collapse" data-target="#collapse-menu-162"><i class="open-icon fa fa-angle-down"></i><i class="close-icon fa fa-angle-up"></i></span><ul class="collapse" id="collapse-menu-162"><li class="item-170"><a href="features/more-features/animated-numbers-and-countdown.html" > Animated Numbers &amp; Countdown</a></li><li class="item-149"><a href="features/more-features/typography.html" > Typography</a></li><li class="item-156"><a href="features/more-features/module-variations.html" > Module Variations</a></li><li class="item-166"><a href="features/more-features/module-positions.html" > Module Positions</a></li><li class="item-167"><a href="../index114a.html?tmpl=comingsoon" > Coming Soon</a></li><li class="item-168"><a href="features/more-features/404-error-page.html" > 404 Error Page</a></li></ul></li><li class="item-163  divider deeper parent"><a class="separator ">Joomla &amp; Virtuemart</a>
<span class="offcanvas-menu-toggler collapsed" data-toggle="collapse" data-target="#collapse-menu-163"><i class="open-icon fa fa-angle-down"></i><i class="close-icon fa fa-angle-up"></i></span><ul class="collapse" id="collapse-menu-163"><li class="item-164"><a href="features/joomla-virtuemart/single-article.html" > Single Article</a></li><li class="item-173"><a href="blog.html" > Category Blog</a></li><li class="item-174"><a href="features/joomla-virtuemart/joomla-registration.html" > Joomla! Registration</a></li><li class="item-175"><a href="features/joomla-virtuemart/search.html" > Search</a></li><li class="item-177"><a href="features/joomla-virtuemart/single-product.html" > Single Product</a></li><li class="item-178"><a href="shop/categories/milk.html" > Product Category</a></li></ul></li></ul></li></ul>
</div></div>
                                                    </div> <!-- /.offcanvas-inner -->
                    </div> <!-- /.offcanvas-menu -->

                    
                    
                    <!-- Preloader -->
                    
                    <!-- Go to top -->
                                            <a href="javascript:void(0)" class="scrollup">&nbsp;</a>
                    
                </body>
                
<!-- Mirrored from dhtheme.com/buttermilk/index.php/shop by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Sep 2019 13:51:12 GMT -->
</html>
