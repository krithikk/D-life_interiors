<?php
include("../connection.php");
session_start();
 if(isset($_POST['submit']))
 {
	$email=$_POST['Email'];
	//echo $email;
	$pass=$_POST['Password'];
	//echo $pass;
	$obj=new db();
	$select="select * from login where email='$email' and password='$pass'";
	//echo $select;
	$data=$obj->execute($select);
	if(mysqli_num_rows($data)>0)
	{
		while($row=mysqli_fetch_array($data))
		{
		
			if($row['role']=='admin')
			{
				$_SESSION['lid']=$row['login_id'];
				$_SESSION['role']=$row['role'];
				header("location:../Admin/adminhome.php");
			}
			if($row['role']=='user')
			{
				$_SESSION['lid']=$row['login_id'];
				$_SESSION['role']=$row['role'];
				header("location:../web_user/userhome.php");
			}
			if($row['role']=='team')
			{
			if($row['logstatus']=='0')
			{
?>
		<script>
          alert(" not approved");
		  window.location="../login/login.php";
</script>
<?php		
		}
	
	else
	{
		$_SESSION['lid']=$row['login_id'];
				$_SESSION['role']=$row['role'];
				header("location:../team home/teamhome.php");
	}
			}
		}
	}
	else
	{
	?>
		<script>
		alert("check username and password");
		window.location="../login/login.php";
		</script>
		<?php
		//echo "err";
	}	
	}
 
?>