<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<div class="header-left-bottom">
	<div class="bg-layer">
	
		
				
	<div class="limiter">
	
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100">
			
				<form action="logaction.php" method="post" class="login100-form validate-form">
					<span class="login100-form-logo"><i class="zmdi zmdi-landscape"></i></span>

					<span class="login100-form-title p-b-34 p-t-27">Log in</span>
                        
					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<!--<span style="right" class="focus-input100" data-placeholder="&#xf207;"></span>-->
						<input class="input100" type="email" name="Email" id="email" placeholder="Email Address" oninput="this.reportValidity()" onchange="em()"  required=""/>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<!--<span class="focus-input100" data-placeholder="&#xf191;"></span>-->
						<input class="input100" type="password" name="Password" id="password"placeholder="Password"  required=""/>
					</div>

					<!--<div class="contact100-form-checkbox">
						<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
						<label class="label-checkbox100" for="ckb1">Remember me</label>
					</div>-->

					<div class="container-login100-form-btn">
						<button type="submit" id="submit" name="submit" class="login100-form-btn">LOGIN</button>
					</div>

					<div class="text-center p-t-90">
						<!--<a class="txt1" href="forgot.php">Forgot Password?</a><br>-->
						<a style="color:white" href="../index.php" > HOME </a>
					</div>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>