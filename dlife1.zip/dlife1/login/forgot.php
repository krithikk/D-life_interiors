<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">

  function checkForm(form)
  {
    if(form.username.value == "") {
      alert("Error: Username cannot be blank!");
      form.username.focus();
      return false;
    }
    re = /^\w+$/;
    if(!re.test(form.username.value)) {
      alert("Error: Username must contain only letters, numbers and underscores!");
      form.username.focus();
      return false;
    }

    if(form.pwd1.value != "" && form.pwd1.value == form.pwd2.value) {
      if(form.pwd1.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        form.pwd1.focus();
        return false;
      }
      if(form.pwd1.value == form.username.value) {
        alert("Error: Password must be different from Username!");
        form.pwd1.focus();
        return false;
      }
      re = /[0-9]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        form.pwd1.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.pwd1.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.pwd1.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      form.pwd1.focus();
      return false;
    }

    alert("You entered a valid password: " + form.pwd1.value);
    return true;
  }

</script>
<style>
body 
{
background-image:url("download (1).jpg");
background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
font-size:"4"; 

}
table
{
background-image:url("");
background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
color:red;
font-size:25;
font-family:times new roman;  
}
 font
{
color:black
font:bold;
}
div{
margin-top:100px;
height:600px;
width:600px;
background-color:NONE;
border-radius: 20px  ;

}
.align-center{
display: block;
margin-left:auto;
margin-right:auto;
}
.align-table{
margin-top:100px;
margin-left:auto;
margin-right:auto;
margin-bottom:auto;
}
.div2{
width:100px;
height:100px;
}
button:hover{background-color: green}
</style>
</head>
<body>

<div class="align-center">
<div class="div2 align-center">

</div>
<form... onsubmit="return checkForm(this);">
<h2><center><fieldset>
<legend>Change Password</legend>
<form ... onsubmit="return checkForm(this);">
<p>Username: <input type="text" name="username"></p>
<p>Password: <input type="password" name="pwd1"></p>
<p>Confirm Password: <input type="password" name="pwd2"></p>
<p><input type="submit"></p></center>
</fieldset>
</form>
</body>
</html>

